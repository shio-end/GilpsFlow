package com.galleryflow.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Local-only profiles and favorites. Videos themselves always come from MediaStore. */
final class ClipStore {
    static final class Profile {
        final String id;
        String name;
        String avatarFile = "";
        String coverFile = "";
        String bio = "";
        String status = "";
        int paletteIndex = 0;
        int layoutIndex = 0;
        final Set<String> likes = new HashSet<>();
        int lastIndex;

        Profile(String id, String name) { this.id = id; this.name = name; }
        int likesCount() { return likes.size(); }
    }

    final ArrayList<Clip> clips = new ArrayList<>();
    final ArrayList<Profile> profiles = new ArrayList<>();
    private final SharedPreferences prefs;
    private String activeId;

    ClipStore(Context context) {
        prefs = context.getSharedPreferences("galleryflow_profiles_v2", Context.MODE_PRIVATE);
        try {
            JSONArray data = new JSONArray(prefs.getString("profiles", "[]"));
            for (int i = 0; i < data.length(); i++) {
                JSONObject obj = data.getJSONObject(i);
                String id = obj.optString("id", "");
                if (id.isEmpty()) continue;
                String label = obj.optString("name", "Viewer");
                Profile p = new Profile(id, label.trim().isEmpty() ? "Viewer" : label);
                p.avatarFile = obj.optString("avatarFile", "");
                p.coverFile = obj.optString("coverFile", "");
                p.bio = limit(obj.optString("bio", ""), 160);
                p.status = limit(obj.optString("status", ""), 48);
                p.paletteIndex = Math.max(0, Math.min(5, obj.optInt("paletteIndex", 0)));
                p.layoutIndex = Math.max(0, Math.min(2, obj.optInt("layoutIndex", 0)));
                JSONArray liked = obj.optJSONArray("likes");
                if (liked != null) for (int j = 0; j < liked.length(); j++) {
                    String key = liked.optString(j, "");
                    if (!key.isEmpty()) p.likes.add(key);
                }
                p.lastIndex = Math.max(0, prefs.getInt("index_" + id, obj.optInt("lastIndex", 0)));
                profiles.add(p);
            }
        } catch (Exception ignored) { profiles.clear(); }
        if (profiles.isEmpty()) {
            Profile initial = new Profile(UUID.randomUUID().toString(), "My space");
            // Preserve liked clips from GalleryFlow 1.x if this is an upgrade.
            SharedPreferences old = context.getSharedPreferences("galleryflow_local_v1", Context.MODE_PRIVATE);
            initial.likes.addAll(old.getStringSet("favorites", new HashSet<>()));
            profiles.add(initial);
            activeId = initial.id;
            save();
        } else {
            activeId = prefs.getString("activeId", profiles.get(0).id);
            if (findProfile(activeId) == null) activeId = profiles.get(0).id;
        }
    }

    void setGallery(ArrayList<Clip> newClips) {
        clips.clear();
        clips.addAll(newClips);
    }

    Profile currentProfile() {
        Profile p = findProfile(activeId);
        return p == null ? profiles.get(0) : p;
    }

    private Profile findProfile(String id) {
        for (Profile p : profiles) if (p.id.equals(id)) return p;
        return null;
    }

    boolean switchProfile(String id) {
        if (findProfile(id) == null) return false;
        activeId = id;
        save();
        return true;
    }

    Profile createProfile(String rawName) {
        String name = cleanName(rawName);
        if (name.isEmpty() || profiles.size() >= 12) return null;
        Profile p = new Profile(UUID.randomUUID().toString(), name);
        profiles.add(p);
        activeId = p.id;
        save();
        return p;
    }

    boolean renameCurrent(String rawName) {
        String name = cleanName(rawName);
        if (name.isEmpty()) return false;
        currentProfile().name = name;
        save();
        return true;
    }

    boolean setCurrentAvatar(String fileName) {
        if (fileName == null || !fileName.matches("face_[a-f0-9\\-]+\\.jpg")) return false;
        currentProfile().avatarFile = fileName;
        save();
        return true;
    }

    boolean setCurrentCover(String fileName) {
        if (fileName == null || !fileName.matches("cover_[a-f0-9\\-]+\\.jpg")) return false;
        currentProfile().coverFile = fileName;
        save(); return true;
    }

    void clearCurrentCover() { currentProfile().coverFile = ""; save(); }
    void setCurrentBio(String value) { currentProfile().bio = limit(value, 160); save(); }
    void setCurrentStatus(String value) { currentProfile().status = limit(value, 48); save(); }
    void setCurrentPalette(int value) {
        currentProfile().paletteIndex = Math.max(0, Math.min(5, value)); save();
    }
    void setCurrentLayout(int value) {
        currentProfile().layoutIndex = Math.max(0, Math.min(2, value)); save();
    }
    private static String limit(String input, int max) {
        String clean = input == null ? "" : input.trim();
        return clean.length() > max ? clean.substring(0, max) : clean;
    }

    boolean removeCurrentProfile() {
        if (profiles.size() <= 1) return false;
        Profile old = currentProfile();
        profiles.remove(old);
        activeId = profiles.get(0).id;
        save();
        return true;
    }

    void replaceProfiles(ArrayList<Profile> restored, String chosen) {
        if (restored == null || restored.isEmpty() || restored.size() > 12) return;
        profiles.clear();
        profiles.addAll(restored);
        activeId = chosen == null ? profiles.get(0).id : chosen;
        if (findProfile(activeId) == null) activeId = profiles.get(0).id;
        save();
    }

    private String cleanName(String raw) {
        String name = raw == null ? "" : raw.trim().replaceAll("\\s+", " ");
        if (name.length() > 24) name = name.substring(0, 24);
        return name;
    }

    boolean isFavorite(Clip clip) { return currentProfile().likes.contains(clip.key()); }
    void toggleFavorite(Clip clip) {
        Set<String> likes = currentProfile().likes;
        if (!likes.add(clip.key())) likes.remove(clip.key());
        save();
    }

    int savedIndex() { return currentProfile().lastIndex; }
    void saveIndex(int index) {
        Profile p = currentProfile();
        p.lastIndex = Math.max(0, index);
        prefs.edit().putInt("index_" + p.id, p.lastIndex).apply();
    }
    boolean shuffleEnabled() { return prefs.getBoolean("shuffle", false); }
    void setShuffle(boolean enabled) { prefs.edit().putBoolean("shuffle", enabled).apply(); }
    boolean muteEnabled() { return prefs.getBoolean("muted", false); }
    void setMute(boolean enabled) { prefs.edit().putBoolean("muted", enabled).apply(); }
    boolean fitEnabled() { return prefs.getBoolean("fit", false); }
    void setFit(boolean enabled) { prefs.edit().putBoolean("fit", enabled).apply(); }

    private void save() {
        JSONArray data = new JSONArray();
        for (Profile p : profiles) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("id", p.id);
                obj.put("name", p.name);
                obj.put("avatarFile", p.avatarFile);
                obj.put("coverFile", p.coverFile);
                obj.put("bio", p.bio);
                obj.put("status", p.status);
                obj.put("paletteIndex", p.paletteIndex);
                obj.put("layoutIndex", p.layoutIndex);
                obj.put("lastIndex", p.lastIndex);
                JSONArray likes = new JSONArray();
                for (String key : p.likes) likes.put(key);
                obj.put("likes", likes);
            } catch (Exception ignored) { }
            data.put(obj);
        }
        prefs.edit().putString("profiles", data.toString())
                .putString("activeId", activeId).apply();
    }
}
