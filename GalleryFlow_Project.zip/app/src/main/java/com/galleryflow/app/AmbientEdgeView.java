package com.galleryflow.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * GalleryFlow ambient edge lighting.
 *
 * Four independent colours are sampled from the corresponding edges of the
 * video. Only the outer part of the screen is tinted, leaving the centre of
 * the picture unaffected. Colour changes crossfade rather than snapping.
 *
 * Original native Android implementation, informed by the general behaviour
 * of WesselKroos/youtube-ambilight (MIT):
 * https://github.com/WesselKroos/youtube-ambilight
 */
final class AmbientEdgeView extends View {
    private static final int LEFT = 0, RIGHT = 1, TOP = 2, BOTTOM = 3;
    private static final int DARK = Color.rgb(17, 19, 20);
    private static final float[] STOPS = {0f, .38f, 1f};

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final int[] displayed = {DARK, DARK, DARK, DARK};
    private final int[] start = {DARK, DARK, DARK, DARK};
    private final int[] destination = {DARK, DARK, DARK, DARK};
    private ValueAnimator transition;
    private boolean hasFrame;
    private float intensity = .86f;

    AmbientEdgeView(Context context) {
        super(context);
        setClickable(false);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    void setIntensity(float amount) {
        intensity = Math.max(0f, Math.min(1.3f, amount));
        invalidate();
    }

    void reset() {
        if (transition != null) { transition.cancel(); transition = null; }
        hasFrame = false;
        for (int i = 0; i < 4; i++) {
            displayed[i] = DARK;
            start[i] = DARK;
            destination[i] = DARK;
        }
        invalidate();
    }

    /** Receives {left,right,top,bottom}; samples are already tonally limited. */
    void setEdgeColors(int[] colors) {
        if (colors == null || colors.length < 4) return;
        boolean different = !hasFrame;
        for (int i = 0; i < 4; i++) {
            if (difference(colors[i], destination[i]) > 12) different = true;
        }
        if (!different) return; // Ignore minor per-frame noise.

        if (transition != null) transition.cancel();
        boolean firstFrame = !hasFrame;
        hasFrame = true;
        for (int i = 0; i < 4; i++) {
            start[i] = displayed[i];
            destination[i] = colors[i] | 0xFF000000;
        }

        transition = ValueAnimator.ofFloat(0f, 1f);
        transition.setInterpolator(new DecelerateInterpolator());
        transition.setDuration(firstFrame ? 380L : 860L);
        transition.addUpdateListener(anim -> {
            float fraction = (float) anim.getAnimatedValue();
            for (int i = 0; i < 4; i++) {
                displayed[i] = blend(start[i], destination[i], fraction);
            }
            invalidate();
        });
        transition.start();
    }

    private static int difference(int a, int b) {
        return Math.abs(Color.red(a) - Color.red(b))
             + Math.abs(Color.green(a) - Color.green(b))
             + Math.abs(Color.blue(a) - Color.blue(b));
    }

    private static int blend(int a, int b, float t) {
        float u = 1f - t;
        return Color.rgb(
                Math.round(Color.red(a) * u + Color.red(b) * t),
                Math.round(Color.green(a) * u + Color.green(b) * t),
                Math.round(Color.blue(a) * u + Color.blue(b) * t));
    }

    private int color(int side, int opacity) {
        int c = displayed[side];
        // Dim bright tones so that white footage does not produce a white flash.
        float brightness = Math.max(Color.red(c), Math.max(Color.green(c), Color.blue(c))) / 255f;
        float brightnessFactor = .52f + .48f * brightness;
        int alpha = Math.max(0, Math.min(255, Math.round(opacity * intensity * brightnessFactor)));
        return Color.argb(alpha, Color.red(c), Color.green(c), Color.blue(c));
    }

    private void drawGlow(Canvas canvas, int side, float x1, float y1, float x2, float y2,
                          float left, float top, float right, float bottom, int peak) {
        int[] stops = {color(side, peak), color(side, Math.round(peak * .39f)), Color.TRANSPARENT};
        paint.setShader(new LinearGradient(x1, y1, x2, y2, stops, STOPS, Shader.TileMode.CLAMP));
        canvas.drawRect(left, top, right, bottom, paint);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!hasFrame || intensity <= 0f) return;
        float w = getWidth(), h = getHeight();
        if (w < 2f || h < 2f) return;

        // Wide and low-opacity gradients mimic blurred light without tinting
        // faces or the centre of the video. Corner overlap stays deliberately soft.
        float horizontal = Math.min(w * .255f, dp(135));
        float vertical = Math.min(h * .185f, dp(142));
        drawGlow(canvas, LEFT, 0, 0, horizontal, 0, 0, 0, horizontal, h, 76);
        drawGlow(canvas, RIGHT, w, 0, w - horizontal, 0, w - horizontal, 0, w, h, 76);
        drawGlow(canvas, TOP, 0, 0, 0, vertical, 0, 0, w, vertical, 46);
        drawGlow(canvas, BOTTOM, 0, h, 0, h - vertical, 0, h - vertical, w, h, 53);
        paint.setShader(null);
    }

    private float dp(float size) { return size * getResources().getDisplayMetrics().density; }

    @Override protected void onDetachedFromWindow() {
        if (transition != null) { transition.cancel(); transition = null; }
        super.onDetachedFromWindow();
    }
}
