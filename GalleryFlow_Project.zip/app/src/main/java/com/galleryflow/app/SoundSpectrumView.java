package com.galleryflow.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Four visual frequency windows from the current audio session; not instrument separation. */
final class SoundSpectrumView extends View {
    private static final int SEGMENTS = 17;
    private static final String[] LABELS = {"LOW", "PULSE", "MID", "AIR"};
    private static final String[] NUMBERS = {"01", "02", "03", "04"};
    private static final int[] COLORS = {0xFFF2AC85, 0xFFE3D48E, 0xFF9BCBB6, 0xFFB9B6EA};
    private static final float[] LOW = {35f, 125f, 300f, 2400f};
    private static final float[] HIGH = {190f, 1350f, 3500f, 11000f};
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float[][] values = new float[4][SEGMENTS];
    private final float[][] targets = new float[4][SEGMENTS];
    private final float density;
    private boolean active;
    private int style;  // 0 TICKS, 1 INK, 2 DOTS
    private int focus = -1; // -1 ALL, otherwise one frequency zone

    SoundSpectrumView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        setContentDescription("Four animated frequency zones; for display, not separated instruments");
    }

    void setStyle(int next) { style = Math.max(0, Math.min(2, next)); invalidate(); }
    int style() { return style; }
    String styleName() { return style == 0 ? "TICKS" : style == 1 ? "INK" : "DOTS"; }
    void setFocus(int value) { focus = value >= 0 && value <= 3 ? value : -1; invalidate(); }
    int focus() { return focus; }
    String focusName() { return focus < 0 ? "ALL FOUR" : LABELS[focus]; }

    void setActive(boolean enabled) {
        active = enabled;
        if (!active) for (float[] row : targets) java.util.Arrays.fill(row, 0f);
        postInvalidateOnAnimation();
    }

    /** FFT callback is not UI-thread; copying to a fixed target avoids heavy drawing in the callback. */
    void acceptFft(byte[] fft, int sampleRateMilliHz) {
        if (!active || fft == null || fft.length < 16 || sampleRateMilliHz <= 0) return;
        float sampleHz = sampleRateMilliHz / 1000f;
        int bins = fft.length / 2;
        float[][] next = new float[4][SEGMENTS];
        for (int band = 0; band < 4; band++) {
            for (int i = 0; i < SEGMENTS; i++) {
                double lo = LOW[band] * Math.pow(HIGH[band] / LOW[band], (double) i / SEGMENTS);
                double hi = LOW[band] * Math.pow(HIGH[band] / LOW[band], (double) (i + 1) / SEGMENTS);
                int start = Math.max(1, Math.min(bins - 1, (int) Math.floor(lo * fft.length / sampleHz)));
                int end = Math.max(start, Math.min(bins - 1, (int) Math.ceil(hi * fft.length / sampleHz)));
                float magnitude = 0;
                for (int k = start; k <= end; k++) {
                    int real = fft[2 * k], imag = fft[2 * k + 1];
                    magnitude = Math.max(magnitude, (float) Math.hypot(real, imag));
                }
                next[band][i] = Math.min(1f, Math.max(0f,
                        (float) (Math.log1p(Math.max(0f, magnitude - 2f)) / Math.log(92))));
            }
        }
        post(() -> {
            if (!active) return;
            for (int b = 0; b < 4; b++) System.arraycopy(next[b], 0, targets[b], 0, SEGMENTS);
            postInvalidateOnAnimation();
        });
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        if (w < 40 || h < 20) return;
        float rowH = h / 4f, labelW = Math.min(85f * density, w * .31f);
        float graphLeft = labelW + 3f * density, graphW = w - graphLeft - 3f * density;
        boolean moving = false;
        for (int b = 0; b < 4; b++) {
            float top = b * rowH, baseY = top + rowH - 7f * density;
            int c = COLORS[b];
            boolean chosen = focus < 0 || focus == b;
            p.setStyle(Paint.Style.FILL);
            p.setColor(chosen ? c : 0xFF6F7277);
            p.setTextSize(9f * getResources().getDisplayMetrics().scaledDensity);
            p.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
            canvas.drawText(NUMBERS[b], 0, top + 12f * density, p);
            p.setTextSize(10.5f * getResources().getDisplayMetrics().scaledDensity);
            canvas.drawText(LABELS[b], 22f * density, top + 12f * density, p);
            p.setColor(0x44C5CED1);
            p.setStrokeWidth(.7f * density);
            canvas.drawLine(graphLeft, baseY, graphLeft + graphW, baseY, p);
            if (style == 1) path.reset();
            float spacing = graphW / SEGMENTS;
            for (int i = 0; i < SEGMENTS; i++) {
                float old = values[b][i], target = active ? targets[b][i] : 0;
                float smooth = target > old ? .32f : .18f;
                float current = old + (target - old) * smooth;
                values[b][i] = current;
                if (Math.abs(current - target) > .008f) moving = true;
                float amplitude = (2f + current * (rowH / density - 13f)) * density;
                float x = graphLeft + spacing * (i + .5f), y = baseY - amplitude;
                p.setColor(c);
                p.setAlpha(chosen ? 245 : 58);
                if (style == 1) {
                    if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
                } else if (style == 2) {
                    canvas.drawCircle(x, y, (1.25f + current * 2.1f) * density, p);
                } else {
                    float thickness = Math.max(1.2f * density, spacing * .36f);
                    canvas.drawRoundRect(x - thickness / 2, y, x + thickness / 2, baseY, thickness / 2, thickness / 2, p);
                }
            }
            if (style == 1) {
                p.setStyle(Paint.Style.STROKE);
                p.setColor(c); p.setAlpha(chosen ? 250 : 70);
                p.setStrokeWidth(2.15f * density);
                p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
                canvas.drawPath(path, p);
                p.setStyle(Paint.Style.FILL);
            }
        }
        if (moving) postInvalidateOnAnimation();
    }
}
