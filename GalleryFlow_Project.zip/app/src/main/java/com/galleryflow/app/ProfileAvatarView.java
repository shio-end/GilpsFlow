package com.galleryflow.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Locale;

/** Reusable rounded portrait with an initial fallback when a local photo isn't chosen. */
final class ProfileAvatarView extends FrameLayout {
    private final ImageView photo;
    private final TextView initial;
    private final int radiusDp;

    ProfileAvatarView(Context context, int radiusDp) {
        super(context);
        this.radiusDp = radiusDp;
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xFFE3C17D);
        background.setCornerRadius(dp(radiusDp));
        setBackground(background);
        setClipToOutline(true);
        photo = new ImageView(context);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        addView(photo, new LayoutParams(-1, -1));
        initial = new TextView(context);
        initial.setTextColor(Color.rgb(30, 28, 28));
        initial.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        initial.setGravity(Gravity.CENTER);
        initial.setTextSize(radiusDp < 25 ? 18 : 33);
        addView(initial, new LayoutParams(-1, -1));
    }

    void showProfile(ClipStore.Profile profile) {
        int[] colors = {0xFFE3C17D, 0xFF8BC9AF, 0xFFFF9B86, 0xFF8AADED, 0xFFC9A5EC, 0xFFB8B9B8};
        GradientDrawable background = new GradientDrawable();
        background.setColor(colors[Math.max(0, Math.min(5, profile.paletteIndex))]);
        background.setCornerRadius(dp(radiusDp));
        setBackground(background);
        Bitmap bitmap = ProfilePhotoStore.load(getContext(), profile.avatarFile);
        if (bitmap != null) {
            photo.setImageBitmap(bitmap);
            photo.setVisibility(VISIBLE);
            initial.setVisibility(GONE);
        } else {
            photo.setImageDrawable(null);
            photo.setVisibility(GONE);
            initial.setVisibility(VISIBLE);
            String name = profile.name == null ? "G" : profile.name.trim();
            initial.setText(name.isEmpty() ? "G" : name.substring(0, 1).toUpperCase(Locale.getDefault()));
        }
        setContentDescription("Profile photo for " + profile.name);
    }
    private int dp(float d) { return (int)(d * getResources().getDisplayMetrics().density + .5f); }
}
