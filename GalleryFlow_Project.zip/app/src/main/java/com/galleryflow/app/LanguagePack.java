package com.galleryflow.app;

import java.util.HashMap;

/** Small offline locale table. English is the initial app language. */
final class LanguagePack {
    private static final HashMap<String, String[]> WORDS = new HashMap<>();
    static {
        put("MAKE IT YOURS  /  PROFILE STUDIO", "个性化 / 档案工作室", "カスタマイズ / プロフィール工房", "แต่งโปรไฟล์ / สตูดิโอส่วนตัว");
        put("AMBIENT STRENGTH", "氛围光强度", "アンビエントライトの強さ", "ความเข้มแสงรอบวิดีโอ");
        put("Soft glow", "柔和", "やわらかい", "นุ่มนวล");
        put("Balanced", "均衡", "標準", "สมดุล");
        put("Vivid", "鲜明", "鮮やか", "สีชัด");
        put("GLIPSFLOW  /  PRIVATE EDITION", "GLIPSFLOW / 私人版", "GLIPSFLOW / プライベート", "GLIPSFLOW / ฉบับส่วนตัว");
        put("✦  MY FILM DIARY", "✦  我的影像日记", "✦  マイフィルム日記", "✦  ไดอารี่วิดีโอของฉัน");
        put("COVER IMAGE", "封面照片", "カバー画像", "รูปปกโปรไฟล์");
        put("Choose profile cover image", "选择个人封面", "プロフィールのカバーを選択", "เลือกรูปปกโปรไฟล์");
        put("REMOVE COVER", "移除封面", "カバーを削除", "นำรูปปกออก");
        put("CHOOSE ↗", "选择 ↗", "選ぶ ↗", "เลือก ↗");
        put("CLEAR ×", "清除 ×", "削除 ×", "ล้าง ×");
        put("PROFILE COLOUR", "档案配色", "プロフィールの色", "สีโปรไฟล์");
        put("PROFILE LAYOUT", "档案布局", "プロフィールのレイアウト", "รูปแบบโปรไฟล์");
        put("SHORT STATUS", "简短状态", "ひとこと", "สถานะสั้น ๆ");
        put("ABOUT ME", "关于我", "自己紹介", "เกี่ยวกับฉัน");
        put("EDIT ↗", "编辑 ↗", "編集 ↗", "แก้ไข ↗");
        put("APPEARANCE", "显示模式", "表示モード", "ธีมแอป");
        put("Follow device", "跟随系统", "端末の設定に従う", "ตามระบบเครื่อง");
        put("System", "系统", "システム", "ตามระบบ");
        put("Light", "浅色", "ライト", "โหมดสว่าง");
        put("Dark", "深色", "ダーク", "โหมดมืด");
        put("Honey", "蜂蜜", "ハニー", "น้ำผึ้ง");
        put("Mint", "薄荷", "ミント", "มินต์");
        put("Peach", "蜜桃", "ピーチ", "พีช");
        put("Sky", "天空", "スカイ", "ฟ้า");
        put("Orchid", "兰紫", "オーキッド", "กล้วยไม้");
        put("Slate", "石板灰", "スレート", "เทาหิน");
        put("Film card", "胶片卡", "フィルムカード", "การ์ดฟิล์ม");
        put("Postcard", "明信片", "ポストカード", "โปสต์การ์ด");
        put("Type first", "文字优先", "文字中心", "เน้นตัวอักษร");
        put("A few words about you", "介绍一下自己", "自己紹介を書いてください", "เขียนแนะนำตัวสั้น ๆ");
        put("Your current mood", "此刻心情", "今の気分", "อารมณ์ตอนนี้");
        put("No image picker available", "没有图片选择器", "画像選択アプリがありません", "ไม่มีตัวเลือกรูปภาพ");
        put("Could not open cover photo", "无法读取封面", "カバー画像を開けません", "เปิดรูปปกไม่ได้");
        put("Cover saved on this phone", "封面已保存在手机中", "カバーを端末に保存しました", "บันทึกรูปปกในเครื่องแล้ว");
        put("YOUR CAMERA ROLL     /     02", "你的相册 / 02", "カメラロール / 02", "คลิปในเครื่อง / 02");
        put("the film shelf.", "影片书架。", "フィルム棚。", "ชั้นวิดีโอ");
        put("Newest clips first · all files stay on this phone", "最新视频在前 · 所有文件留在手机", "新しい順 · ファイルは端末内のみ", "คลิปล่าสุดอยู่บนสุด · ทุกไฟล์อยู่ในเครื่อง");
        put("No videos yet.\nAllow gallery access to get started.", "还没有视频。\n请允许读取相册。", "動画がありません。\nギャラリーのアクセスを許可してください。", "ยังไม่มีวิดีโอ\nอนุญาตเข้าถึงแกลเลอรีเพื่อเริ่มต้น");
        put("Your shelf is empty.\nTap ♥ on a film to keep it here.", "书架还是空的。\n点击 ♥ 收藏视频。", "ライブラリは空です。\n♥を押すとここに保存されます。", "ชั้นวิดีโอยังว่าง\nกด ♥ เพื่อเก็บคลิปที่นี่");
        put("Studio  /  clean sans", "Studio / 无衬线", "Studio / ゴシック", "Studio / เรียบง่าย");
        put("Editorial  /  classic serif", "Editorial / 经典衬线", "Editorial / 明朝体", "Editorial / เซอริฟคลาสสิก");
        put("Narrow  /  condensed", "Narrow / 窄体", "Narrow / 細身", "Narrow / ตัวแคบ");
        put("Mono  /  typewriter", "Mono / 打字机", "Mono / 等幅", "Mono / พิมพ์ดีด");
        put("Soft  /  informal", "Soft / 柔和", "Soft / やわらか", "Soft / นุ่มนวล");
        put("Custom  /  import TTF or OTF", "自定义 / 导入 TTF 或 OTF", "カスタム / TTF・OTF を取り込む", "กำหนดเอง / นำเข้า TTF หรือ OTF");
        put("PERSONAL ARCHIVE   /   NO. 01", "私人档案 / 01", "プライベートアーカイブ / 01", "คลังส่วนตัว / 01");
        put("Your little corner.", "你的小角落。", "自分だけの場所。", "มุมส่วนตัวของคุณ");
        put("ONLY ON THIS PHONE", "仅在此手机上", "この端末だけ", "เฉพาะในเครื่องนี้");
        put("EDIT PHOTO  ↗", "编辑照片 ↗", "写真を編集 ↗", "แก้ไขรูป ↗");
        put("SWITCH PROFILES", "切换档案", "プロフィール切替", "สลับโปรไฟล์");
        put("＋  NEW LOCAL PROFILE", "＋ 新建本地档案", "＋ プロフィールを追加", "＋ เพิ่มโปรไฟล์ใหม่");
        put("RENAME", "重命名", "名前を変更", "เปลี่ยนชื่อ");
        put("DELETE PROFILE", "删除档案", "プロフィール削除", "ลบโปรไฟล์");
        put("the contact sheet.", "影片目录。", "コンタクトシート。", "แผงภาพคลิป");
        put("◉  YOUR CORNER", "◉ 你的空间", "◉ 自分の場所", "◉ มุมของคุณ");
        put("↻ REFRESH", "↻ 刷新", "↻ 更新", "↻ รีเฟรช");
        put("♥  MY SAVES", "♥ 我的收藏", "♥ お気に入り", "♥ ที่ชอบ");
        put("Delete", "删除", "削除", "ลบ");
        put("Restore", "恢复", "復元", "กู้คืน");
        put("Backup saved. Keep this file safe.", "备份完成，请妥善保管。", "バックアップを保存しました。大切に保管してください。", "สำรองข้อมูลแล้ว โปรดเก็บไฟล์ไว้");
        put("Could not save backup", "无法保存备份", "バックアップを保存できません", "บันทึกข้อมูลสำรองไม่ได้");
        put("Profiles and likes restored", "档案和收藏已恢复", "プロフィールとお気に入りを復元しました", "กู้คืนโปรไฟล์และรายการถูกใจแล้ว");
        put("Invalid or unreadable GlipsFlow backup", "备份文件无效或无法读取", "バックアップファイルを読み取れません", "ไฟล์สำรองไม่ถูกต้องหรืออ่านไม่ได้");
        put("Save", "保存", "保存", "บันทึก");
        put("Create", "创建", "作成", "สร้าง");
        put("Create local profile", "创建本地档案", "プロフィールを作成", "สร้างโปรไฟล์ในเครื่อง");
        put("Rename profile", "重命名档案", "プロフィールの名前を変更", "เปลี่ยนชื่อโปรไฟล์");
        put("Delete this profile?", "删除此档案？", "このプロフィールを削除しますか？", "ลบโปรไฟล์นี้ไหม?");
        put("Delete this local profile?", "删除此本地档案？", "ローカルプロフィールを削除しますか？", "ลบโปรไฟล์ในเครื่องนี้ไหม?");
        put("Restore local profiles?", "恢复本地档案？", "ローカルプロフィールを復元しますか？", "กู้คืนโปรไฟล์ในเครื่องไหม?");
        put("Only this profile, its portrait, and saved likes will be deleted. Your gallery videos are not deleted.", "仅删除此档案、头像和收藏，不会删除相册视频。", "このプロフィール・写真・お気に入りのみ削除します。動画は削除しません。", "ลบเฉพาะโปรไฟล์ รูป และรายการถูกใจ ไม่ลบวิดีโอจริง");
        put("This will replace profiles, their pictures and likes inside GlipsFlow. Original videos will not be changed.", "将替换 GlipsFlow 中的档案、头像和收藏，原视频不变。", "プロフィール・写真・お気に入りを置き換えます。動画は変更されません。", "จะเขียนทับโปรไฟล์ รูป และรายการถูกใจในแอป แต่ไม่กระทบวิดีโอจริง");
        put("Android requires audio permission to visualize sound from the video player. GlipsFlow does not record or upload microphone audio. These are visual frequency zones, not isolated instruments.", "Android 需要音频权限才能显示播放器的声波。GlipsFlow 不会录音或上传麦克风音频。此功能仅显示频段，不分离乐器。", "波形表示には Android の音声権限が必要です。GlipsFlow はマイクを録音・送信しません。楽器の分離ではなく周波数の表示です。", "Android ต้องใช้สิทธิ์เสียงเพื่อแสดงคลื่นจากคลิป GlipsFlow ไม่บันทึกหรืออัปโหลดเสียงไมค์ และไม่ได้แยกเครื่องดนตรีจริง");
        put("Coral", "珊瑚橙", "コーラル", "ส้มคอรัล");
        put("Powder Blue", "浅蓝", "パウダーブルー", "ฟ้าพาวเดอร์");
        put("Sage", "鼠尾草绿", "セージ", "เขียวเสจ");
        put("WATCH", "观看", "見る", "ดูคลิป");
        put("SHELF", "片库", "ライブラリ", "คลังคลิป");
        put("YOU", "我的", "自分", "โปรไฟล์");
        put("TICKS", "刻度", "目盛り", "ขีด");
        put("INK", "墨线", "インク", "หมึก");
        put("DOTS", "圆点", "ドット", "จุด");
        put("LIKE", "喜欢", "いいね", "ถูกใจ");
        put("SOUNDS", "声音", "サウンド", "เสียง");
        put("MIX", "随机", "シャッフル", "สุ่ม");
        put("FIT", "适应", "全体表示", "พอดีจอ");
        put("SOUND", "声音", "音声", "เสียง");
        put("FOUR FREQUENCY WINDOWS", "四段频率", "4つの周波数帯", "4 ช่วงความถี่");
        put("sound room", "声音空间", "サウンドルーム", "ห้องเสียง");
        put("TAP: DRAWING STYLE   ·   HOLD: FOCUS BAND", "点击：更换波形 · 长按：选频段", "タップ：描画変更・長押し：帯域選択", "แตะเปลี่ยนลาย · กดค้างเลือกย่านเสียง");
        put("ALL 04", "全部 04", "全4帯域", "ทั้งหมด 04");
        put("Open Sound Room?", "打开声音空间？", "サウンドルームを開きますか？", "เปิดห้องเสียงไหม?");
        put("Not now", "暂不", "後で", "ไว้ก่อน");
        put("Continue", "继续", "続ける", "ดำเนินการต่อ");
        put("●  OFFLINE / MY SPACE", "● 离线 / 我的空间", "● オフライン / 自分の場所", "● ออฟไลน์ / พื้นที่ของฉัน");
        put("YOUR OWN LITTLE CINEMA  /  NO UPLOADS", "你的私人影院 / 无需上传", "小さな自分の映画館 / アップロードなし", "โรงหนังส่วนตัว / ไม่อัปโหลด");
        put("SWIPE UP FOR NEXT VIDEO  ↑", "上滑切换下一段视频 ↑", "上にスワイプで次へ ↑", "ปัดขึ้นเพื่อดูคลิปถัดไป ↑");
        put("ONLY YOUR VIDEOS   ·   OFFLINE", "仅本机视频 · 离线", "端末の動画だけ · オフライン", "เฉพาะวิดีโอในเครื่อง · ออฟไลน์");
        put("YOUR FILM ROLL   /   PRIVATE COLLECTION", "你的胶片卷 / 私人收藏", "マイフィルム / プライベートコレクション", "ม้วนฟิล์มของคุณ / คลังส่วนตัว");
        put("A cinema\nof your own.", "你的私人\n小影院。", "自分だけの\n小さな映画館。", "โรงหนัง\nของคุณเอง");
        put("Allow video access to build your private feed.\nNo account. No uploads. Just your gallery.", "允许读取视频以创建私人信息流。\n无需账号，无需上传，仅显示本机视频。", "動画へのアクセスを許可すると、自分だけのフィードを作成。\nアカウントもアップロードも不要です。", "อนุญาตเข้าถึงวิดีโอเพื่อสร้างฟีดส่วนตัว\nไม่ต้องมีบัญชี ไม่ต้องอัปโหลด");
        put("ALLOW VIDEO ACCESS    ↗", "允许访问视频 ↗", "動画アクセスを許可 ↗", "อนุญาตเข้าถึงวิดีโอ ↗");
        put("REFRESH GALLERY    ↻", "刷新相册 ↻", "ギャラリーを更新 ↻", "รีเฟรชแกลเลอรี ↻");
        put("CHOOSE MORE VIDEOS    ↗", "选择更多视频 ↗", "動画をさらに選ぶ ↗", "เลือกวิดีโอเพิ่ม ↗");
        put("VIDEOS STAY ON YOUR PHONE · LOCAL ONLY", "视频仅保留在手机中", "動画は端末内だけに保存", "วิดีโออยู่ในโทรศัพท์เท่านั้น");
        put("BUILT FOR YOUR CAMERA ROLL.     ↗", "为你的相册而设计 ↗", "端末の動画のために ↗", "สร้างเพื่อคลิปในเครื่อง ↗");
        put("Your gallery.\nYour feed.", "你的相册。\n你的动态。", "あなたの動画。\nあなたのフィード。", "แกลเลอรีของคุณ\nฟีดของคุณ");
        put("No videos found in the accessible gallery.\nYou can refresh or select more videos in Android settings.", "没有找到可读取的视频。\n可以刷新或在 Android 设置中授权更多视频。", "許可済みの動画がありません。\n更新するか、Android設定で追加してください。", "ไม่พบวิดีโอที่เข้าถึงได้\nรีเฟรชหรืออนุญาตเพิ่มในการตั้งค่า Android");
        put("Give GlipsFlow access to videos on your phone.\nNothing is uploaded and no login is needed.", "允许 GlipsFlow 读取手机视频。\n无需登录，也不会上传。", "GlipsFlow に動画の読み取りを許可してください。\nログイン・アップロードは不要です。", "อนุญาตให้ GlipsFlow อ่านวิดีโอในเครื่อง\nไม่ต้องล็อกอินและไม่มีการอัปโหลด");
        put("Finding your\nvideos...", "正在查找\n视频…", "動画を\n探しています…", "กำลังค้นหา\nวิดีโอ...");
        put("Scanning the videos Android lets GlipsFlow access.\nNothing is copied or uploaded.", "正在扫描允许读取的视频。\n不会复制或上传。", "許可された動画を調べています。\nコピーやアップロードはしません。", "กำลังสแกนวิดีโอที่อนุญาต\nไม่คัดลอกหรืออัปโหลด");
        put("SCANNING GALLERY  ↻", "正在扫描相册 ↻", "ギャラリーを確認中 ↻", "กำลังสแกนแกลเลอรี ↻");
        put("Video permission not granted", "未授予视频权限", "動画へのアクセスが許可されていません", "ยังไม่ได้รับอนุญาตเข้าถึงวิดีโอ");
        put("Sound waves stay off without audio permission", "没有音频权限，声波保持关闭", "音声の権限がないため波形はオフです", "ไม่มีสิทธิ์เสียง จึงปิดคลื่นเสียงไว้");
        put("Could not read the gallery. Check video access.", "无法读取相册，请检查权限。", "ギャラリーを読めません。権限を確認してください。", "อ่านแกลเลอรีไม่ได้ โปรดตรวจสิทธิ์");
        put("Showing only the videos you allowed", "仅显示你允许的视频", "許可された動画のみ表示します", "แสดงเฉพาะคลิปที่อนุญาต");
        put("Shuffle on", "已开启随机播放", "シャッフルをオン", "เปิดสุ่มคลิป");
        put("Shuffle off", "已关闭随机播放", "シャッフルをオフ", "ปิดสุ่มคลิป");
        put("DATE UNKNOWN", "日期未知", "日付不明", "ไม่ทราบวันที่");
        put("ALL FILMS", "全部视频", "すべての動画", "ทุกคลิป");
        put("♥  KEEPERS", "♥ 已收藏", "♥ お気に入り", "♥ ที่ชอบ");
        put("NEWEST FIRST", "最新优先", "新しい順", "ล่าสุดก่อน");
        put("GALLERY ACCESS ↗", "相册权限 ↗", "ギャラリーの権限 ↗", "สิทธิ์แกลเลอรี ↗");
        put("WATCH FILMS ↗", "观看视频 ↗", "動画を見る ↗", "ดูวิดีโอ ↗");
        put("GLIPS / SOUND ROOM   /   03", "G/F 音频实验 / 03", "G/F 音の実験 / 03", "G/F ทดลองเสียง / 03");
        put("see the", "看见", "見える", "มองเห็น");
        put("sound.", "声音。", "音。", "เสียง");
        put("Four visual frequency ranges from the playing video · no instrument separation", "当前视频的4段可视化频率 · 不分离乐器", "再生中の動画を4帯域で表示 · 楽器の分離はしません", "แสดงความถี่จากคลิปเป็น 4 ย่าน · ไม่แยกเครื่องดนตรีจริง");
        put("NO VIDEO SELECTED", "未选择视频", "動画未選択", "ยังไม่ได้เลือกคลิป");
        put("CHOOSE VIDEOS IN SHELF ↗", "从片库选择视频 ↗", "ライブラリから動画を選ぶ ↗", "เลือกคลิปจากคลัง ↗");
        put("◌  THE ROOM IS QUIET\n\nTurn on waves to see the sound frequencies move.", "◌ 声音空间尚未开启\n\n打开声波，查看频率变化。", "◌ サウンドルームは待機中\n\n波形をオンにして音の動きを見ましょう。", "◌ ห้องเสียงยังเงียบ\n\nเปิดคลื่นเพื่อดูการเคลื่อนไหวของเสียง");
        put("TURN WAVES OFF  ×", "关闭声波 ×", "波形をオフ ×", "ปิดคลื่น ×");
        put("START THE WAVES  ↗", "开启声波 ↗", "波形をオン ↗", "เปิดคลื่น ↗");
        put("Tap: change pattern  ·  Hold: focus a frequency", "点击：切换样式 · 长按：聚焦频段", "タップ：模様変更 · 長押し：帯域を選択", "แตะเปลี่ยนลาย · กดค้างเน้นย่านเสียง");
        put("LOCAL AUDIO SESSION ONLY   /   NO RECORDING   /   NO UPLOAD", "仅本地音频 / 不录音 / 不上传", "端末内の音声のみ / 録音なし / アップロードなし", "เสียงในเครื่องเท่านั้น / ไม่บันทึก / ไม่อัปโหลด");
        put("PERSONAL ARCHIVE     /     04", "私人档案 / 04", "プライベートアーカイブ / 04", "คลังส่วนตัว / 04");
        put("your corner.", "你的角落。", "自分の場所。", "มุมของคุณ");
        put("No online account · No followers · No sign-in", "无在线账号 · 无关注者 · 无需登录", "オンラインアカウントなし · フォロワーなし · ログイン不要", "ไม่มีบัญชีออนไลน์ · ไม่มีผู้ติดตาม · ไม่ต้องล็อกอิน");
        put("CHANGE PORTRAIT  ↗", "更换头像 ↗", "写真を変更 ↗", "เปลี่ยนรูปโปรไฟล์ ↗");
        put("◉  CHANGE PHOTO", "◉ 更换照片", "◉ 写真を変更", "◉ เปลี่ยนรูป");
        put("RENAME ↗", "重命名 ↗", "名前を変更 ↗", "เปลี่ยนชื่อ ↗");
        put("CHANGE FONT ↗", "更换字体 ↗", "フォント変更 ↗", "เปลี่ยนฟอนต์ ↗");
        put("TYPEFACE", "字体", "フォント", "แบบอักษร");
        put("YOUR LOCAL PROFILES", "你的本地档案", "ローカルプロフィール", "โปรไฟล์ในเครื่อง");
        put("+  ADD LOCAL PROFILE", "+ 新建本地档案", "＋ プロフィールを追加", "+ เพิ่มโปรไฟล์ในเครื่อง");
        put("THE KEEPERS  ·  ♥", "收藏的视频 · ♥", "お気に入り · ♥", "คลิปที่ชอบ · ♥");
        put("No saved videos yet.\nTap ♥ while watching to keep a film here.", "还没有收藏的视频。\n观看时点按 ♥ 即可收藏。", "お気に入りはまだありません。\n再生中に♥を押して保存しましょう。", "ยังไม่มีคลิปที่ชอบ\nกด ♥ ระหว่างดูเพื่อเก็บไว้ที่นี่");
        put("VIEW ALL KEPT FILMS  ↗", "查看全部收藏 ↗", "お気に入りをすべて見る ↗", "ดูคลิปที่ชอบทั้งหมด ↗");
        put("KEEP YOUR ARCHIVE SAFE", "备份你的档案", "アーカイブを守る", "สำรองคลังของคุณ");
        put("Save names, portraits and likes to a file before replacing the APK or changing phones.", "更换 APK 或手机前，先备份姓名、头像和收藏。", "APKの入れ替えや機種変更前に、名前・写真・お気に入りを保存。", "สำรองชื่อ รูป และคลิปที่ชอบก่อนเปลี่ยน APK หรือเครื่อง");
        put("BACK UP ↗", "备份 ↗", "バックアップ ↗", "สำรองข้อมูล ↗");
        put("RESTORE ↗", "恢复 ↗", "復元 ↗", "กู้คืน ↗");
        put("DELETE THIS PROFILE", "删除此档案", "このプロフィールを削除", "ลบโปรไฟล์นี้");
        put("STORAGE  /  THIS DEVICE", "存储空间 / 此设备", "ストレージ / この端末", "พื้นที่จัดเก็บ / เครื่องนี้");
        put("DEVICE TOTAL", "设备总容量", "端末の総容量", "ความจุเครื่อง");
        put("YOUR VIDEOS", "视频占用", "動画の容量", "พื้นที่วิดีโอ");
        put("SPACE LEFT", "剩余空间", "空き容量", "พื้นที่เหลือ");
        put("●  VIDEOS", "● 视频", "● 動画", "● วิดีโอ");
        put("●  OTHER USED", "●  其他已用", "●  その他の使用量", "● ใช้งานอื่น ๆ");
        put("●  FREE", "●  可用", "●  空き", "● ว่าง");
        put("Bar uses this phone's primary storage. Video bytes are an estimate from readable clips.", "以手机主存储为基准；视频大小根据可访问的文件估算。", "端末のメインストレージを基準に、見える動画の容量を推定。", "ใช้พื้นที่หลักของเครื่องเป็นฐาน ขนาดวิดีโอประมาณจากคลิปที่อ่านได้");
        put("Bar uses this phone's primary storage. Video size includes only clips you allowed.", "以手机主存储为基准；仅统计已授权视频。", "端末のメインストレージを基準に、許可された動画のみ集計。", "ใช้พื้นที่หลักของเครื่อง และนับเฉพาะคลิปที่อนุญาต");
        put("APP LANGUAGE", "应用语言", "アプリの言語", "ภาษาแอป");
        put("ACCENT COLOUR", "主题色", "アクセントカラー", "สีหลัก");
        put("AMBIENT LIGHT", "氛围光", "アンビエントライト", "แสงรอบวิดีโอ");
        put("FOCUS MODE", "专注模式", "フォーカスモード", "โหมดซ่อนรายละเอียด");
        put("ON  ◉", "开启 ◉", "オン ◉", "เปิด ◉");
        put("OFF  ○", "关闭 ○", "オフ ○", "ปิด ○");
        put("Hide video details", "隐藏视频信息", "動画の詳細を隠す", "ซ่อนรายละเอียดคลิป");
        put("Show video details", "显示视频信息", "動画の詳細を表示", "แสดงรายละเอียดคลิป");
        put("Cancel", "取消", "キャンセル", "ยกเลิก");
        put("Choose your type", "选择字体", "フォントを選択", "เลือกฟอนต์");
        put("Choose a TTF or OTF font first", "请先选择 TTF 或 OTF 字体", "まず TTF または OTF を選んでください", "เลือกฟอนต์ TTF หรือ OTF ก่อน");
        put("Profile picture saved on this phone", "头像已保存到手机", "プロフィール写真を端末に保存しました", "บันทึกรูปโปรไฟล์ในเครื่องแล้ว");
        put("At least one profile is required", "至少保留一个档案", "プロフィールを1つ残してください", "ต้องมีอย่างน้อยหนึ่งโปรไฟล์");
        put("Showing first 150 videos here. Keep swiping to watch the rest.", "此处显示前150个视频，上滑可继续观看。", "ここには最初の150本を表示。スワイプで続きを見られます。", "แสดง 150 คลิปแรก ปัดดูคลิปที่เหลือได้");
        put("No liked videos yet.\nTap ♥ on a video to save it for this profile.", "还没有收藏的视频。\n点按 ♥ 即可为此档案收藏。", "お気に入りはありません。\n♥を押すと保存できます。", "ยังไม่มีคลิปที่ชอบ\nกด ♥ เพื่อบันทึกในโปรไฟล์นี้");
    }
    private static void put(String en, String zh, String ja, String th) {
        WORDS.put(en, new String[]{zh, ja, th});
    }
    static String t(String source, String lang) {
        if (source == null || "en".equals(lang)) return source;
        int idx = "zh".equals(lang) ? 0 : "ja".equals(lang) ? 1 : "th".equals(lang) ? 2 : -1;
        if (idx < 0) return source;
        String[] direct = WORDS.get(source);
        if (direct != null) return direct[idx];
        if (source.endsWith(" ↗")) {
            String[] style = WORDS.get(source.substring(0, source.length() - 2));
            if (style != null) return style[idx] + " ↗";
        }
        // Translate known UI prefixes only; never translate video filenames.
        if (source.endsWith(" VIDEOS  /  NEWEST FIRST")) {
            String[] words = {" 个视频 / 最新优先", " 本の動画 / 新しい順", " คลิป / ล่าสุดก่อน"};
            return source.replace(" VIDEOS  /  NEWEST FIRST", words[idx]);
        }
        if (source.contains(" VIDEOS  /  SAVED BY ")) {
            String[] words = {" 个视频 / 收藏者 ", " 本の動画 / 保存者 ", " คลิป / บันทึกโดย "};
            return source.replace(" VIDEOS  /  SAVED BY ", words[idx]);
        }
        if (source.startsWith("TYPEFACE  /  ")) return t("TYPEFACE", lang) + "  /  " + source.substring(13);
        if (source.startsWith("●  PRIVATE / ")) {
            String[] words = {"● 私人 / ", "● プライベート / ", "● ส่วนตัว / "};
            return words[idx] + source.substring(13);
        }
        if (source.startsWith("LATEST FIRST  ·  ")) {
            String[] words = {"最新优先", "新しい順", "ล่าสุดก่อน"};
            return words[idx] + " · " + source.substring(17).replace("SWIPE ↑",
                new String[]{"上滑 ↑", "上にスワイプ ↑", "ปัดขึ้น ↑"}[idx]);
        }
        if (source.startsWith("NOW PLAYING   /   ")) {
            String[] words = {"正在播放 / ", "再生中 / ", "กำลังเล่น / "};
            return words[idx] + source.substring(18);
        }
        if (source.endsWith(" kept films  ·  local profile")) {
            String[] words = {" 个收藏 · 本地档案", " 本のお気に入り · ローカル", " คลิปที่ชอบ · โปรไฟล์ในเครื่อง"};
            return source.replace(" kept films  ·  local profile", words[idx]);
        }
        if (source.endsWith(" SAVED")) {
            String[] words = {" 已收藏", " 保存済み", " ที่ชอบ"};
            return source.replace(" SAVED", words[idx]);
        }
        if (source.startsWith("TYPEFACE") && source.contains(" / "))
            return t("TYPEFACE", lang) + source.substring(8);
        return source;
    }
    private LanguagePack() {}
}
