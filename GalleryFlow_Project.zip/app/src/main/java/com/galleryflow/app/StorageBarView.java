package com.galleryflow.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Three-part bar; visible video bytes are a subset of used phone storage. */
final class StorageBarView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF area = new RectF();
    private final float videoPart, otherPart;
    private final int accent;
    private final boolean darkTheme;

    StorageBarView(Context context, long total, long free, long visibleVideos, int accent, boolean darkTheme) {
        super(context);
        this.accent = accent;
        this.darkTheme = darkTheme;
        long safeTotal = Math.max(0L, total);
        long safeFree = Math.min(safeTotal, Math.max(0L, free));
        long used = safeTotal - safeFree;
        long video = Math.min(used, Math.max(0L, visibleVideos));
        videoPart = safeTotal == 0 ? 0f : video / (float) safeTotal;
        otherPart = safeTotal == 0 ? 0f : (used - video) / (float) safeTotal;
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    private float dp(int n) { return n * getResources().getDisplayMetrics().density; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = dp(1), top = dp(1), right = getWidth() - dp(1), bottom = getHeight() - dp(1);
        if (right <= left || bottom <= top) return;
        area.set(left, top, right, bottom);
        float round = dp(7);
        path.reset(); path.addRoundRect(area, round, round, Path.Direction.CW);
        canvas.save(); canvas.clipPath(path);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(darkTheme ? 0xFFB0B9BA : 0xFFD4D6D2);
        canvas.drawRect(area, paint); // free
        float width = area.width();
        if (otherPart > 0f) {
            paint.setColor(darkTheme ? 0xFF617171 : 0xFF303431);
            canvas.drawRect(left, top, left + width * (videoPart + otherPart), bottom, paint);
        }
        if (videoPart > 0f) {
            paint.setColor(accent);
            canvas.drawRect(left, top, left + width * videoPart, bottom, paint);
        }
        canvas.restore();
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(1));
        paint.setColor(darkTheme ? 0xFF627271 : 0xFF9DA29C); canvas.drawRoundRect(area, round, round, paint);
        paint.setStyle(Paint.Style.FILL);
    }
}
