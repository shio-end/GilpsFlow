package com.galleryflow.app;

import android.net.Uri;

/** A read-only reference to a video indexed by Android MediaStore. */
final class Clip {
    final Uri uri;
    final String title;
    final long addedAtMillis;
    final long durationMillis;
    final long sizeBytes;

    Clip(Uri uri, String title, long addedAtMillis, long durationMillis, long sizeBytes) {
        this.uri = uri;
        this.title = title;
        this.addedAtMillis = addedAtMillis;
        this.durationMillis = durationMillis;
        this.sizeBytes = Math.max(0L, sizeBytes);
    }

    String key() { return uri.toString(); }
}
