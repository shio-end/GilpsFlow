package com.galleryflow.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;

/** Copies a user-picked image to app-private storage. No cloud, photo-library scan, or login. */
final class ProfilePhotoStore {
    private ProfilePhotoStore() { }

    static String save(Context context, Uri source) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = context.getContentResolver().openInputStream(source)) {
            if (in == null) throw new IllegalArgumentException("Image not available");
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IllegalArgumentException("Unsupported image");
        BitmapFactory.Options options = new BitmapFactory.Options();
        int size = Math.max(bounds.outWidth, bounds.outHeight);
        int scale = 1;
        while (size / scale > 768 && scale < 256) scale *= 2;
        options.inSampleSize = scale;
        Bitmap bitmap;
        try (InputStream in = context.getContentResolver().openInputStream(source)) {
            if (in == null) throw new IllegalArgumentException("Image unavailable");
            bitmap = BitmapFactory.decodeStream(in, null, options);
        }
        if (bitmap == null) throw new IllegalArgumentException("Cannot read image");
        // Respect photo rotation stored by Android camera apps (when metadata is available).
        int orientation = ExifInterface.ORIENTATION_NORMAL;
        try (InputStream in = context.getContentResolver().openInputStream(source)) {
            if (in != null) orientation = new ExifInterface(in).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
        } catch (Exception ignored) { }
        Matrix rotation = new Matrix();
        if (orientation == ExifInterface.ORIENTATION_ROTATE_90) rotation.postRotate(90);
        else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) rotation.postRotate(180);
        else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) rotation.postRotate(270);
        if (!rotation.isIdentity()) {
            Bitmap corrected = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), rotation, true);
            if (corrected != bitmap) bitmap.recycle();
            bitmap = corrected;
        }
        int width = bitmap.getWidth(), height = bitmap.getHeight();
        int side = Math.min(width, height);
        int target = Math.min(480, side);
        // Crop the centre: profile portraits should fill a circle without distortion.
        Bitmap cropped = Bitmap.createBitmap(bitmap, (width - side) / 2, (height - side) / 2, side, side);
        Bitmap small = Bitmap.createScaledBitmap(cropped, target, target, true);
        File folder = new File(context.getFilesDir(), "profile_photos");
        if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Cannot create avatar folder");
        String fileName = "face_" + UUID.randomUUID().toString() + ".jpg";
        File destination = new File(folder, fileName);
        try (FileOutputStream out = new FileOutputStream(destination)) {
            if (!small.compress(Bitmap.CompressFormat.JPEG, 85, out)) throw new IllegalStateException("Cannot save image");
        } catch (Exception e) {
            destination.delete();
            throw e;
        } finally {
            if (small != cropped) small.recycle();
            if (cropped != bitmap) cropped.recycle();
            bitmap.recycle();
        }
        return fileName;
    }

    /** Import a landscape cover, keep file private and limit its size. */
    static String saveCover(Context context, Uri source) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = context.getContentResolver().openInputStream(source)) {
            if (in == null) throw new IllegalArgumentException("Image unavailable");
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IllegalArgumentException("Unsupported picture");
        BitmapFactory.Options options = new BitmapFactory.Options();
        int scale = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / scale > 1600 && scale < 256) scale *= 2;
        options.inSampleSize = scale;
        Bitmap image;
        try (InputStream in = context.getContentResolver().openInputStream(source)) {
            if (in == null) throw new IllegalArgumentException("Image unavailable");
            image = BitmapFactory.decodeStream(in, null, options);
        }
        if (image == null) throw new IllegalArgumentException("Image decode failed");
        try {
            int orientation = ExifInterface.ORIENTATION_NORMAL;
            try (InputStream in = context.getContentResolver().openInputStream(source)) {
                if (in != null) orientation = new ExifInterface(in).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            } catch (Exception ignored) { }
            Matrix matrix = new Matrix();
            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) matrix.postRotate(90);
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) matrix.postRotate(180);
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) matrix.postRotate(270);
            if (!matrix.isIdentity()) {
                Bitmap rotated = Bitmap.createBitmap(image, 0, 0, image.getWidth(), image.getHeight(), matrix, true);
                if (rotated != image) { image.recycle(); image = rotated; }
            }
            final float ratio = 2.4f;
            int w = image.getWidth(), h = image.getHeight();
            int cw = Math.min(w, Math.round(h * ratio));
            int ch = Math.min(h, Math.round(w / ratio));
            Bitmap cropped = Bitmap.createBitmap(image, (w - cw) / 2, (h - ch) / 2, cw, ch);
            Bitmap output = Bitmap.createScaledBitmap(cropped, 960, 400, true);
            File folder = new File(context.getFilesDir(), "profile_photos");
            if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Cannot create photo folder");
            String fileName = "cover_" + UUID.randomUUID().toString() + ".jpg";
            File target = new File(folder, fileName);
            try (FileOutputStream out = new FileOutputStream(target)) {
                if (!output.compress(Bitmap.CompressFormat.JPEG, 82, out))
                    throw new IllegalStateException("Cannot save banner");
            } catch (Exception e) { target.delete(); throw e; }
            finally {
                if (output != cropped) output.recycle();
                if (cropped != image) cropped.recycle();
            }
            return fileName;
        } finally { image.recycle(); }
    }

    static Bitmap loadCover(Context context, String fileName) {
        if (fileName == null || !fileName.matches("cover_[a-f0-9\\-]+\\.jpg")) return null;
        File source = new File(new File(context.getFilesDir(), "profile_photos"), fileName);
        return source.isFile() ? BitmapFactory.decodeFile(source.getAbsolutePath()) : null;
    }

    static Bitmap load(Context context, String fileName) {
        if (fileName == null || !fileName.matches("face_[a-f0-9\\-]+\\.jpg")) return null;
        File file = new File(new File(context.getFilesDir(), "profile_photos"), fileName);
        if (!file.isFile()) return null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 2;
        return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
    }

    static void delete(Context context, String fileName) {
        if (fileName == null || !fileName.matches("(face|cover)_[a-f0-9\\-]+\\.jpg")) return;
        new File(new File(context.getFilesDir(), "profile_photos"), fileName).delete();
    }
}
