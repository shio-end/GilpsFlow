package com.galleryflow.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

/** A prepared video panel. Only the active panel produces audio or playback. */
final class VideoPage extends FrameLayout implements TextureView.SurfaceTextureListener {
    interface Listener { void onReady(VideoPage page); void onProblem(VideoPage page); }

    final Clip clip;
    private final TextureView texture;
    private final ImageView poster;
    private final ProgressBar loading;
    private final TextView errorText;
    private final Listener listener;
    private MediaPlayer player;
    private boolean released;
    private boolean prepared;
    private boolean active;
    private boolean muted;
    private boolean fit;
    private boolean hasVideoFrame;
    private int videoW, videoH;

    VideoPage(Context c, Clip clip, Listener callback, boolean muted, boolean fit) {
        super(c);
        this.clip = clip;
        this.listener = callback;
        this.muted = muted;
        this.fit = fit;
        setBackgroundColor(Color.rgb(12, 14, 18));

        poster = new ImageView(c);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackgroundColor(Color.rgb(21, 24, 30));
        addView(poster, new LayoutParams(-1, -1));
        ThumbnailLoader.load(c, clip, poster);

        texture = new TextureView(c);
        addView(texture, new LayoutParams(-1, -1));
        texture.setSurfaceTextureListener(this);
        // Poster must remain on top of the player until the first frame renders.
        bringChildToFront(poster);

        loading = new ProgressBar(c);
        loading.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Color.rgb(218, 245, 118)));
        LayoutParams spin = new LayoutParams(dp(30), dp(30), Gravity.CENTER);
        addView(loading, spin);

        errorText = new TextView(c);
        errorText.setText("Can't play this file\nSwipe to try another video");
        errorText.setTextColor(Color.WHITE);
        errorText.setTextSize(15);
        errorText.setGravity(Gravity.CENTER);
        errorText.setVisibility(View.GONE);
        LayoutParams err = new LayoutParams(-1, -2, Gravity.CENTER);
        err.leftMargin = err.rightMargin = dp(32);
        addView(errorText, err);
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
        if (released) return;
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .setUsage(AudioAttributes.USAGE_MEDIA).build());
            mp.setDataSource(getContext(), clip.uri);
            Surface surface = new Surface(st);
            mp.setSurface(surface);
            surface.release();
            mp.setOnVideoSizeChangedListener((p, w, h) -> {
                if (released) return;
                videoW = w; videoH = h; applyVideoTransform();
            });
            mp.setOnPreparedListener(p -> {
                if (released) return;
                prepared = true;
                videoW = p.getVideoWidth(); videoH = p.getVideoHeight();
                p.setLooping(true);
                applyVideoTransform();
                p.setVolume(muted ? 0f : 1f, muted ? 0f : 1f);
                loading.setVisibility(View.GONE);
                if (active) start();
                if (listener != null) listener.onReady(this);
            });
            mp.setOnInfoListener((p, what, extra) -> {
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) {
                    hasVideoFrame = true;
                    poster.setVisibility(View.GONE);
                }
                return false;
            });
            mp.setOnErrorListener((p, what, extra) -> {
                showError();
                return true;
            });
            mp.prepareAsync();
        } catch (Exception e) { showError(); }
    }

    private void showError() {
        loading.setVisibility(View.GONE);
        errorText.setVisibility(View.VISIBLE);
        if (listener != null) listener.onProblem(this);
    }

    private void applyVideoTransform() {
        if (videoW == 0 || videoH == 0 || texture.getWidth() == 0 || texture.getHeight() == 0) return;
        float viewW = texture.getWidth(), viewH = texture.getHeight();
        float scale = fit ? Math.min(viewW / videoW, viewH / videoH)
                          : Math.max(viewW / videoW, viewH / videoH);
        float contentW = videoW * scale, contentH = videoH * scale;
        Matrix m = new Matrix();
        m.setScale(contentW / viewW, contentH / viewH, viewW / 2f, viewH / 2f);
        texture.setTransform(m);
    }

    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) { applyVideoTransform(); }
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { release(); return true; }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }

    void setActive(boolean newActive) {
        active = newActive;
        if (active) start(); else pause();
    }

    void start() {
        if (!prepared || player == null || released) return;
        try {
            player.start();
            if (hasVideoFrame) poster.setVisibility(View.GONE);
            // Some vendor decoders do not emit MEDIA_INFO_VIDEO_RENDERING_START.
            postDelayed(() -> {
                if (!released && active && prepared) poster.setVisibility(View.GONE);
            }, 240);
        } catch (IllegalStateException ignored) { }
    }

    void pause() {
        if (!prepared || player == null || released) return;
        try { if (player.isPlaying()) player.pause(); } catch (IllegalStateException ignored) { }
    }

    /** Valid only after the video is prepared. Used by the opt-in visualizer. */
    int audioSessionId() {
        if (!prepared || player == null || released) return -1;
        try { return player.getAudioSessionId(); } catch (RuntimeException ignored) { return -1; }
    }

    boolean isPlaying() {
        if (!prepared || player == null || released) return false;
        try { return player.isPlaying(); } catch (IllegalStateException e) { return false; }
    }

    /**
     * Read a small thumbnail of the *displayed* frame, about once per second.
     * Sample each side independently instead of averaging the entire picture.
     * This avoids a single disconnected colour washing over all four edges.
     * The bitmap is temporary and never leaves the device.
     */
    int[] sampleAmbientEdges() {
        if (released || !prepared || !texture.isAvailable() || !isPlaying()) return null;
        final int w = 48, h = 80;
        Bitmap bmp = null;
        try {
            bmp = texture.getBitmap(w, h);
            if (bmp == null) return null;
            int[] pixels = new int[w * h];
            bmp.getPixels(pixels, 0, w, 0, 0, w, h);
            return new int[]{
                    readEdgeColor(pixels, w, h, 0),  // left
                    readEdgeColor(pixels, w, h, 1),  // right
                    readEdgeColor(pixels, w, h, 2),  // top
                    readEdgeColor(pixels, w, h, 3)   // bottom
            };
        } catch (RuntimeException ignored) {
            return null; // Decoder may temporarily block TextureView snapshots.
        } finally {
            if (bmp != null) bmp.recycle();
        }
    }

    private static int readEdgeColor(int[] pixels, int width, int height, int side) {
        long red = 0, green = 0, blue = 0, count = 0;
        // Scan a narrow edge region, skipping dark letterboxing pixels. For
        // pillarboxed footage, the second pass searches a little farther in.
        for (int pass = 0; pass < 2; pass++) {
            int left = side == 0 ? (pass == 0 ? 2 : 10) :
                    side == 1 ? (pass == 0 ? width - 11 : width - 19) : 5;
            int right = side == 0 ? (pass == 0 ? 10 : 18) :
                    side == 1 ? (pass == 0 ? width - 3 : width - 11) : width - 5;
            int top = side == 2 ? (pass == 0 ? 2 : 11) :
                    side == 3 ? (pass == 0 ? height - 17 : height - 28) : 11;
            int bottom = side == 2 ? (pass == 0 ? 16 : 27) :
                    side == 3 ? (pass == 0 ? height - 3 : height - 17) : height - 11;
            for (int y = top; y < bottom; y += 2) {
                for (int x = left; x < right; x += 2) {
                    int pixel = pixels[y * width + x];
                    int r = Color.red(pixel), g = Color.green(pixel), b = Color.blue(pixel);
                    int brightest = Math.max(r, Math.max(g, b));
                    // Ignore black borders and near-black decoder artifacts.
                    if (brightest < 29) continue;
                    red += r; green += g; blue += b; count++;
                }
            }
            if (count >= 7) break;
        }
        if (count == 0) return Color.rgb(18, 19, 21);

        int avg = Color.rgb((int)(red / count), (int)(green / count), (int)(blue / count));
        float[] hsv = new float[3];
        Color.colorToHSV(avg, hsv);
        // Keep the actual hue, but suppress oversaturated and overly bright
        // highlights to make transitions feel like soft reflected light.
        hsv[1] = Math.min(.66f, hsv[1] * .82f);
        hsv[2] = Math.min(.79f, hsv[2] * .91f);
        return Color.HSVToColor(hsv);
    }

    void setMuted(boolean value) {
        muted = value;
        if (prepared && player != null) {
            try { player.setVolume(muted ? 0f : 1f, muted ? 0f : 1f); } catch (Exception ignored) { }
        }
    }

    void setFit(boolean value) { fit = value; applyVideoTransform(); }
    int duration() {
        if (!prepared || player == null) return 0;
        try { return Math.max(0, player.getDuration()); } catch (Exception ignored) { return 0; }
    }
    int position() {
        if (!prepared || player == null) return 0;
        try { return Math.max(0, player.getCurrentPosition()); } catch (Exception ignored) { return 0; }
    }
    void seekTo(int ms) {
        if (!prepared || player == null) return;
        try { player.seekTo(Math.max(0, Math.min(duration(), ms))); } catch (Exception ignored) { }
    }

    void release() {
        if (released) return;
        released = true;
        prepared = false;
        if (player != null) {
            try { player.setOnPreparedListener(null); player.setOnInfoListener(null);
                  player.setOnErrorListener(null); player.setOnVideoSizeChangedListener(null);
                  player.reset(); }
            catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }
    @Override protected void onDetachedFromWindow() { release(); super.onDetachedFromWindow(); }
}
