package com.galleryflow.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ThumbnailLoader {
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(12 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount() / 1024; }
    };
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void load(Context context, Clip clip, ImageView target) {
        final String key = clip.key();
        target.setTag(key);
        Bitmap cached = CACHE.get(key);
        if (cached != null) { target.setImageBitmap(cached); return; }
        target.setImageDrawable(null);
        Context app = context.getApplicationContext();
        POOL.execute(() -> {
            Bitmap frame = null;
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            try {
                retriever.setDataSource(app, clip.uri);
                if (android.os.Build.VERSION.SDK_INT >= 27) {
                    frame = retriever.getScaledFrameAtTime(250_000,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 240, 360);
                } else {
                    Bitmap original = retriever.getFrameAtTime(250_000,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (original != null) {
                        int w = original.getWidth(), h = original.getHeight();
                        float scale = Math.min(1f, 360f / Math.max(w, h));
                        frame = Bitmap.createScaledBitmap(original,
                                Math.max(1, (int) (w * scale)), Math.max(1, (int) (h * scale)), true);
                        if (frame != original) original.recycle();
                    }
                }
                if (frame != null) CACHE.put(key, frame);
            } catch (Exception ignored) { }
            finally { try { retriever.release(); } catch (Exception ignored) { } }
            Bitmap result = frame;
            MAIN.post(() -> { if (key.equals(target.getTag()) && result != null) target.setImageBitmap(result); });
        });
    }
}
