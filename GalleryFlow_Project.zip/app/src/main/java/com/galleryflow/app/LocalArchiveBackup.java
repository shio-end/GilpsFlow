package com.galleryflow.app;

import android.content.Context;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.UUID;

/** Portable local archive for profiles, avatars and hearts. No original videos are copied. */
final class LocalArchiveBackup {
    private LocalArchiveBackup() { }
    static void exportTo(Context context, ClipStore store, OutputStream output) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("format", "glipsflow.local.v1");
        payload.put("activeId", store.currentProfile().id);
        JSONArray people = new JSONArray();
        for (ClipStore.Profile person : store.profiles) {
            JSONObject data = new JSONObject();
            data.put("id", person.id); data.put("name", person.name);
            data.put("index", person.lastIndex);
            data.put("bio", person.bio);
            data.put("status", person.status);
            data.put("paletteIndex", person.paletteIndex);
            data.put("layoutIndex", person.layoutIndex);
            JSONArray likes = new JSONArray();
            for (String videoId : person.likes) likes.put(videoId);
            data.put("likes", likes);
            if (person.avatarFile != null && person.avatarFile.matches("face_[a-f0-9\\-]+\\.jpg")) {
                File avatar = new File(new File(context.getFilesDir(), "profile_photos"), person.avatarFile);
                if (avatar.isFile() && avatar.length() <= 1024 * 1024) {
                    byte[] bytes = new byte[(int) avatar.length()];
                    try (FileInputStream stream = new FileInputStream(avatar)) {
                        int pointer = 0;
                        while (pointer < bytes.length) {
                            int n = stream.read(bytes, pointer, bytes.length - pointer);
                            if (n <= 0) break;
                            pointer += n;
                        }
                        if (pointer == bytes.length)
                            data.put("portrait", Base64.encodeToString(bytes, Base64.NO_WRAP));
                    }
                }
            }
            if (person.coverFile != null && person.coverFile.matches("cover_[a-f0-9\\-]+\\.jpg")) {
                File cover = new File(new File(context.getFilesDir(), "profile_photos"), person.coverFile);
                if (cover.isFile() && cover.length() <= 1024 * 1024) {
                    byte[] bytes = new byte[(int) cover.length()];
                    try (FileInputStream stream = new FileInputStream(cover)) {
                        int position = 0, n;
                        while (position < bytes.length && (n = stream.read(bytes, position, bytes.length - position)) > 0)
                            position += n;
                        if (position == bytes.length) data.put("coverImage", Base64.encodeToString(bytes, Base64.NO_WRAP));
                    }
                }
            }
            people.put(data);
        }
        payload.put("profiles", people);
        byte[] serialized = payload.toString(2).getBytes("UTF-8");
        output.write(serialized); output.flush();
    }

    static void importFrom(Context context, ClipStore store, InputStream input) throws Exception {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[8192];
        int total = 0;
        int count;
        while ((count = input.read(data)) != -1) {
            total += count;
            if (total > 8 * 1024 * 1024) throw new IllegalArgumentException("Archive too large");
            buffer.write(data, 0, count);
        }
        JSONObject payload = new JSONObject(buffer.toString("UTF-8"));
        String archiveFormat = payload.optString("format");
        if (!"galleryflow.local.v1".equals(archiveFormat)
                && !"glipsflow.local.v1".equals(archiveFormat))
            throw new IllegalArgumentException("Not a GlipsFlow or GalleryFlow archive");
        JSONArray entries = payload.optJSONArray("profiles");
        if (entries == null || entries.length() < 1 || entries.length() > 12)
            throw new IllegalArgumentException("Invalid profile count");
        ArrayList<ClipStore.Profile> restored = new ArrayList<>();
        String restoreActive = payload.optString("activeId");
        ArrayList<String> createdPhotos = new ArrayList<>();
        String mappedActive = null;
        try {
            File folder = new File(context.getFilesDir(), "profile_photos");
            if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Cannot store pictures");
            for (int i = 0; i < entries.length(); i++) {
                JSONObject row = entries.getJSONObject(i);
                String oldId = row.optString("id", "");
                String name = row.optString("name", "Viewer").trim();
                if (name.isEmpty()) name = "Viewer";
                if (name.length() > 24) name = name.substring(0, 24);
                ClipStore.Profile profile = new ClipStore.Profile(UUID.randomUUID().toString(), name);
                profile.lastIndex = Math.max(0, row.optInt("index", 0));
                String bio = row.optString("bio", "");
                profile.bio = bio.substring(0, Math.min(160, bio.length()));
                String status = row.optString("status", "");
                profile.status = status.substring(0, Math.min(48, status.length()));
                profile.paletteIndex = Math.max(0, Math.min(5, row.optInt("paletteIndex", 0)));
                profile.layoutIndex = Math.max(0, Math.min(2, row.optInt("layoutIndex", 0)));
                JSONArray liked = row.optJSONArray("likes");
                if (liked != null) {
                    int cap = Math.min(50000, liked.length());
                    for (int j = 0; j < cap; j++) {
                        String key = liked.optString(j, "");
                        if (!key.isEmpty() && key.length() < 512) profile.likes.add(key);
                    }
                }
                String encoded = row.optString("portrait", "");
                if (!encoded.isEmpty()) {
                    if (encoded.length() > 1600000) throw new IllegalArgumentException("Invalid portrait size");
                    byte[] raw = Base64.decode(encoded, Base64.DEFAULT);
                    if (raw.length > 1024 * 1024) throw new IllegalArgumentException("Invalid portrait size");
                    String fname = "face_" + UUID.randomUUID().toString() + ".jpg";
                    File target = new File(folder, fname);
                    try (FileOutputStream out = new FileOutputStream(target)) { out.write(raw); }
                    profile.avatarFile = fname;
                    createdPhotos.add(fname);
                }
                String banner = row.optString("coverImage", "");
                if (!banner.isEmpty()) {
                    if (banner.length() > 1600000) throw new IllegalArgumentException("Invalid cover size");
                    byte[] raw = Base64.decode(banner, Base64.DEFAULT);
                    if (raw.length > 1024 * 1024) throw new IllegalArgumentException("Invalid cover size");
                    String fname = "cover_" + UUID.randomUUID().toString() + ".jpg";
                    try (FileOutputStream out = new FileOutputStream(new File(folder, fname))) { out.write(raw); }
                    profile.coverFile = fname;
                    createdPhotos.add(fname);
                }
                if (oldId.equals(restoreActive)) mappedActive = profile.id;
                restored.add(profile);
            }
            store.replaceProfiles(restored, mappedActive);
        } catch (Exception error) {
            for (String file : createdPhotos) ProfilePhotoStore.delete(context, file);
            throw error;
        }
    }
}
