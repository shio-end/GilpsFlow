package com.galleryflow.app;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import java.util.ArrayList;

/** Reads only video metadata from MediaStore. No files are copied or uploaded. */
final class MediaGallery {
    static ArrayList<Clip> findVideos(Context context) {
        ArrayList<Clip> found = new ArrayList<>();
        Uri source = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.DATE_MODIFIED,
                MediaStore.Video.Media.DURATION,
                MediaStore.MediaColumns.SIZE
        };
        String sortBy = MediaStore.Video.Media.DATE_ADDED + " DESC, "
                + MediaStore.Video.Media._ID + " DESC";
        try (Cursor cursor = context.getContentResolver().query(
                source, projection, null, null, sortBy)) {
            if (cursor == null) return found;
            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
            int addedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED);
            int modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED);
            int durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);
            int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE);
            while (cursor.moveToNext()) {
                long id = cursor.getLong(idCol);
                String fileName = cursor.getString(nameCol);
                if (fileName == null || fileName.trim().isEmpty()) fileName = "Video " + id;
                String title = fileName;
                int dot = title.lastIndexOf('.');
                if (dot > 0) title = title.substring(0, dot);
                long added = cursor.getLong(addedCol);
                if (added <= 0) added = cursor.getLong(modifiedCol);
                long duration = Math.max(0L, cursor.getLong(durationCol));
                long sizeBytes = Math.max(0L, cursor.getLong(sizeCol));
                found.add(new Clip(ContentUris.withAppendedId(source, id), title,
                        Math.max(0L, added) * 1000L, duration, sizeBytes));
            }
        }
        return found;
    }

    private MediaGallery() { }
}
