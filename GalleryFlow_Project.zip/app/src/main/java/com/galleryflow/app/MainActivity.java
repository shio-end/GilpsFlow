package com.galleryflow.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.provider.MediaStore;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Environment;
import android.os.StatFs;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.GridView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;

/** GlipsFlow: private, vertical, swipe-to-watch video gallery. */
public final class MainActivity extends Activity implements VideoPage.Listener {
    private static final int ASK_VIDEOS = 202;
    private static final int ASK_SOUND = 203;
    private static final int PICK_PHOTO = 204;
    private static final int EXPORT_ARCHIVE = 205;
    private static final int IMPORT_ARCHIVE = 206;
    private static final int PICK_FONT = 207;
    private static final int PICK_COVER = 208;
    private static final String FONT_SETTINGS = "galleryflow_type_v1";
    private static final String FONT_LOCAL_FILE = "galleryflow_user_font.otf";
    private static final String[] FONT_STYLES = {"Studio", "Editorial", "Narrow", "Mono", "Soft", "Custom"};
    private static final int NIGHT = 0xFF151515;
    private static final int WHITE = 0xFFFAF7F0;
    private static final int MUTED = 0xFFBAB7B1;
    private static final int CORAL = 0xFFE67F6E;
    private static final int CARD = 0xFF29292A;
    private static final int PAPER = 0xFFF9F4EB;
    private static final int INK = 0xFF1F1F1F;
    private static final int RUST = 0xFFAD5D4E;
    private static final String UI_SETTINGS = "galleryflow_interface_v7";
    private static final String[] ACCENT_NAMES = {"Coral", "Powder Blue", "Peach", "Sage"};
    private static final String[] THEMES = {"System", "Light", "Dark"};
    private static final String[] PROFILE_COLORS = {"Honey", "Mint", "Peach", "Sky", "Orchid", "Slate"};
    private static final int[] PROFILE_PALETTE = {
            0xFFE3C17D, 0xFF8BC9AF, 0xFFFF9B86, 0xFF8AADED, 0xFFC9A5EC, 0xFFB8B9B8};
    private static final String[] PROFILE_LAYOUTS = {"Film card", "Postcard", "Type first"};
    private int themeMode = 0; // 0 follow Android, 1 force light, 2 force dark
    private String coverProfileId;
    private static final int[] ACCENTS = {0xFFE67F6E, 0xFFB7D3F6, 0xFFE7B19A, 0xFFB4CDA6};
    private final String[] languageCodes = {"en", "zh", "ja", "th"};
    private String appLanguage = "en";
    private int accentIndex = 0;
    private boolean ambientEnabled = true;
    private static final String[] AMBIENT_STRENGTHS = {"Soft glow", "Balanced", "Vivid"};
    private static final float[] AMBIENT_LEVELS = {.50f, .86f, 1.16f};
    private int ambientStrengthIndex = 1;
    private boolean focusMode = false;
    private AmbientEdgeView ambientGlow;
    private long lastAmbientSample = 0L;
    private LinearLayout hudUpper, hudInfo, hudPlayback;
    private View toolSound, toolShuffle, toolFit, toolMute;
    private TextView focusToggle;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final Runnable mediaChanged = () -> { if (hasVideoAccess()) refreshGallery(); };
    private final ContentObserver galleryObserver = new ContentObserver(handler) {
        @Override public void onChange(boolean selfChange) {
            handler.removeCallbacks(mediaChanged);
            handler.postDelayed(mediaChanged, 1200);
        }
    };
    private final ExecutorService scanWorker = Executors.newSingleThreadExecutor();
    private boolean scanBusy, scanPending;
    private boolean alreadyDestroyed;

    private ClipStore store;
    private FrameLayout root, stage, overlay, empty, tapArea, sectionHost;
    private LinearLayout navigation;
    private final TextView[] navItems = new TextView[3];
    private static final int[] NAV_TABS = {0, 1, 3};
    private int selectedTab = 0; // WATCH, SHELF, SOUND, YOU
    private boolean shelfLikedOnly = false;
    private VideoPage current, incoming, stagedNext;
    private int currentIndex = 0, incomingIndex = -1, stagedNextIndex = -1;
    private boolean wantedPlaying = true;
    private boolean shuffle, muted, fit, isDragging, isAnimating, isScrubbing;
    private boolean soundEnabled;
    private boolean screenActive = true;
    private SoundSpectrumView spectrumView;
    private SoundSpectrumController soundController;
    private FrameLayout spectrumPanel;
    private TextView soundIcon, spectrumModeLabel, spectrumFocusLabel;
    private ProfileAvatarView headerAvatar;
    private String photoProfileId;
    private String fontStyle = "Studio";
    private Typeface customTypeface;
    private float touchDownY, touchDownX;
    private int direction;
    private final ArrayList<Integer> history = new ArrayList<>();
    private int historyPos;
    private int pendingRandom = -1;

    private TextView currentNumber, titleText, hintText, favoriteIcon, shuffleIcon, muteIcon, fitIcon, timerText, pauseBadge;
    private TextView profileLabel, emptyTitle, emptyDescription, emptyButton;
    private SeekBar seekBar;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (current != null && seekBar != null) {
                int duration = current.duration();
                int position = current.position();
                if (!isScrubbing) {
                    seekBar.setMax(Math.max(1, duration));
                    seekBar.setProgress(position);
                    timerText.setText(time(position) + "   /   " + time(duration));
                }
            }
            updateAmbientOnTick();
            handler.postDelayed(this, 300);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setBackgroundDrawable(new ColorDrawable(NIGHT));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();
        store = new ClipStore(this);
        loadUiSettings();
        loadFontSettings();
        shuffle = store.shuffleEnabled(); muted = store.muteEnabled(); fit = store.fitEnabled();
        soundEnabled = getSharedPreferences("galleryflow_display_v3", MODE_PRIVATE)
                .getBoolean("audio_visuals", false);
        currentIndex = 0;
        history.add(0);
        createInterface();
        showEmpty();
        int restoreTab = state == null ? 0 : state.getInt("galleryflow_tab", 0);
        if (restoreTab != 0) handler.post(() -> selectTab(restoreTab));
        try { getContentResolver().registerContentObserver(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, galleryObserver); }
        catch (Exception ignored) { }
        // The user can deny access. Only request once automatically, never nag on resume.
        handler.postDelayed(() -> {
            if (!isFinishing() && !isDestroyed()) {
                if (hasVideoAccess()) refreshGallery();
                else if (!getSharedPreferences("galleryflow_permission_v2", MODE_PRIVATE)
                        .getBoolean("asked", false)) {
                    getSharedPreferences("galleryflow_permission_v2", MODE_PRIVATE)
                            .edit().putBoolean("asked", true).apply();
                    requestVideoAccess();
                }
            }
        }, 550);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putInt("galleryflow_tab", selectedTab);
        super.onSaveInstanceState(outState);
    }

    private void loadUiSettings() {
        android.content.SharedPreferences pref = getSharedPreferences(UI_SETTINGS, MODE_PRIVATE);
        appLanguage = pref.getString("language", "en");
        if (!"en".equals(appLanguage) && !"zh".equals(appLanguage)
                && !"ja".equals(appLanguage) && !"th".equals(appLanguage)) appLanguage = "en";
        accentIndex = Math.max(0, Math.min(ACCENTS.length - 1, pref.getInt("accent", 0)));
        ambientEnabled = pref.getBoolean("ambient", true);
        ambientStrengthIndex = Math.max(0, Math.min(AMBIENT_LEVELS.length - 1,
                pref.getInt("ambient_strength", 1)));
        focusMode = pref.getBoolean("focus", false);
        themeMode = Math.max(0, Math.min(2, pref.getInt("theme_mode", 0)));
    }

    private int accent() { return ACCENTS[accentIndex]; }
    private int shadeForWhite() {
        float[] hsv = new float[3]; Color.colorToHSV(accent(), hsv);
        hsv[2] = Math.min(hsv[2], .52f);
        hsv[1] = Math.max(hsv[1], .65f);
        return Color.HSVToColor(hsv);
    }
    /** Light/dark applies to SHELF and YOU. WATCH and SOUND keep their cinematic dark surfaces. */
    private boolean darkPaper() {
        if (selectedTab != 1 && selectedTab != 3) return false;
        if (themeMode == 2) return true;
        if (themeMode == 1) return false;
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }
    private int palette(int color) {
        if (color == CORAL) return accent();
        if (color == RUST) return darkPaper() ? accent() : shadeForWhite();
        if (darkPaper()) {
            if (color == INK) return 0xFFF5F4ED;
            if (color == PAPER) return 0xFF161B1C;
            if (color == 0xFF77766F || color == 0xFF77776F || color == 0xFF77796D ||
                    color == 0xFF686C62 || color == 0xFF666B61 || color == 0xFF646867)
                return 0xFFB5BCB6;
            if (color == 0xFF898E8A) return 0xFFBAC4BE;
            if (color == 0xFFF4F1E8 || color == 0xFFE2DFD6 || color == 0xFFEAE7DE)
                return 0xFF252C2D;
        }
        if (color == 0xFFF4F1E8 || color == 0xFFE2DFD6 || color == 0xFFEAE7DE) return WHITE;
        return color;
    }
    private int surface(int color) {
        if (!darkPaper()) return palette(color);
        if (color == WHITE || color == 0xFFF5F2EA || color == 0xFFF3F0E8 ||
                color == 0xFFF4F1E8 || color == 0xFFE2DED2 || color == 0xFFE5E1D7 ||
                color == 0xFFE2DFD6 || color == 0xFFE0DDCF || color == 0xFFF6F3EA)
            return 0xFF252C2E;
        if (color == 0xFFD3CFC3) return 0xFF303A3D;
        if (color == 0xFFD6D8D4 || color == 0xFFCAC5B7 || color == 0xFFC9C9BE ||
                color == 0xFFCECABF || color == 0xFFBFC0B3 || color == 0xFFCCC8BC)
            return 0xFF515B5D;
        return palette(color);
    }
    private void chooseThemeMode() {
        String[] names = {tr("Follow device"), tr("Light"), tr("Dark")};
        new AlertDialog.Builder(this).setTitle(tr("APPEARANCE"))
                .setSingleChoiceItems(names, themeMode, (dialog, index) -> {
                    dialog.dismiss();
                    getSharedPreferences(UI_SETTINGS, MODE_PRIVATE).edit()
                            .putInt("theme_mode", index).apply();
                    recreate();
                }).setNegativeButton(tr("Cancel"), null).show();
    }

    private String tr(String input) { return LanguagePack.t(input, appLanguage); }

    private void updateAmbientOnTick() {
        if (ambientGlow == null) return;
        boolean visible = ambientEnabled && selectedTab == 0 && screenActive
                && current != null && current.isPlaying() && !isAnimating;
        ambientGlow.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (!visible) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastAmbientSample < 1050L) return;
        lastAmbientSample = now;
        int[] sampled = current.sampleAmbientEdges();
        if (sampled != null) ambientGlow.setEdgeColors(sampled);
    }

    private String languageLabel() {
        switch (appLanguage) {
            case "zh": return "简体中文";
            case "ja": return "日本語";
            case "th": return "ไทย";
            default: return "English";
        }
    }

    private void chooseLanguage() {
        String[] names = {"English", "简体中文", "日本語", "ไทย"};
        int chosen = 0;
        for (int i = 0; i < languageCodes.length; i++)
            if (languageCodes[i].equals(appLanguage)) chosen = i;
        new AlertDialog.Builder(this)
                .setTitle(tr("APP LANGUAGE"))
                .setSingleChoiceItems(names, chosen, (dialog, which) -> {
                    dialog.dismiss();
                    getSharedPreferences(UI_SETTINGS, MODE_PRIVATE).edit()
                            .putString("language", languageCodes[which]).apply();
                    recreate();
                }).setNegativeButton(tr("Cancel"), null).show();
    }

    private void chooseAccent() {
        String[] names = {"●  " + tr("Coral"), "●  " + tr("Powder Blue"),
                "●  " + tr("Peach"), "●  " + tr("Sage")};
        new AlertDialog.Builder(this)
                .setTitle(tr("ACCENT COLOUR"))
                .setSingleChoiceItems(names, accentIndex, (dialog, which) -> {
                    dialog.dismiss();
                    getSharedPreferences(UI_SETTINGS, MODE_PRIVATE).edit()
                            .putInt("accent", which).apply();
                    recreate();
                }).setNegativeButton(tr("Cancel"), null).show();
    }

    private void chooseAmbientStrength() {
        String[] choices = new String[AMBIENT_STRENGTHS.length];
        for (int i = 0; i < choices.length; i++) choices[i] = tr(AMBIENT_STRENGTHS[i]);
        new AlertDialog.Builder(this)
                .setTitle(tr("AMBIENT STRENGTH"))
                .setSingleChoiceItems(choices, ambientStrengthIndex, (dialog, which) -> {
                    dialog.dismiss();
                    ambientStrengthIndex = which;
                    getSharedPreferences(UI_SETTINGS, MODE_PRIVATE).edit()
                            .putInt("ambient_strength", which).apply();
                    if (ambientGlow != null) ambientGlow.setIntensity(AMBIENT_LEVELS[which]);
                    if (selectedTab == 3) renderProfileScreen();
                }).setNegativeButton(tr("Cancel"), null).show();
    }

    private void setAmbientEnabled(boolean enabled) {
        ambientEnabled = enabled;
        getSharedPreferences(UI_SETTINGS, MODE_PRIVATE).edit().putBoolean("ambient", enabled).apply();
        if (ambientGlow != null) ambientGlow.setVisibility(enabled && selectedTab == 0
                ? View.VISIBLE : View.GONE);
        lastAmbientSample = 0;
        if (ambientGlow != null && !enabled) ambientGlow.reset();
        if (selectedTab == 3) renderProfileScreen();
    }

    private void setFocusMode(boolean enabled) {
        focusMode = enabled;
        getSharedPreferences(UI_SETTINGS, MODE_PRIVATE).edit().putBoolean("focus", enabled).apply();
        applyFocusMode();
        if (selectedTab == 3) renderProfileScreen();
    }

    private void applyFocusMode() {
        int state = focusMode ? View.GONE : View.VISIBLE;
        if (hudUpper != null) hudUpper.setVisibility(state);
        if (hudInfo != null) hudInfo.setVisibility(state);
        if (hudPlayback != null) hudPlayback.setVisibility(state);
        if (toolSound != null) toolSound.setVisibility(state);
        if (toolShuffle != null) toolShuffle.setVisibility(state);
        if (toolFit != null) toolFit.setVisibility(state);
        if (toolMute != null) toolMute.setVisibility(state);
        if (favoriteIcon != null && favoriteIcon.getParent() instanceof LinearLayout) {
            LinearLayout favRow = (LinearLayout) favoriteIcon.getParent();
            if (favRow.getChildCount() > 1) favRow.getChildAt(1).setVisibility(state);
        }
        if (focusToggle != null) {
            focusToggle.setText(focusMode ? "▣" : "◫");
            focusToggle.setContentDescription(focusMode ? tr("Show video details") : tr("Hide video details"));
        }
    }

    private void addSettingRow(LinearLayout parent, String title, String action, Runnable onTap) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(52));
        rp.topMargin = dp(5); parent.addView(row, rp);
        TextView caption = text(title, 11, INK, true);
        row.addView(caption, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView chip = actionChip(action, false, true);
        row.addView(chip, new LinearLayout.LayoutParams(dp(150), dp(42)));
        chip.setOnClickListener(v -> onTap.run());
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void createInterface() {
        root = new FrameLayout(this); root.setBackgroundColor(NIGHT);
        setContentView(root);
        stage = new FrameLayout(this);
        stage.setClipChildren(true);
        stage.setBackgroundColor(NIGHT);
        root.addView(stage, new FrameLayout.LayoutParams(-1, -1));
        ambientGlow = new AmbientEdgeView(this);
        ambientGlow.setIntensity(AMBIENT_LEVELS[ambientStrengthIndex]);
        ambientGlow.setVisibility(View.GONE);
        root.addView(ambientGlow, new FrameLayout.LayoutParams(-1, -1));
        tapArea = new FrameLayout(this);
        tapArea.setBackgroundColor(Color.TRANSPARENT);
        root.addView(tapArea, new FrameLayout.LayoutParams(-1, -1));
        tapArea.setOnTouchListener(this::handleSwipe);
        createHUD();
        createSpectrumPanel();
        createEmptyState();
        sectionHost = new FrameLayout(this);
        root.addView(sectionHost, new FrameLayout.LayoutParams(-1, -1));
        sectionHost.setVisibility(View.GONE);
        createNavigation();
        applyFocusMode();
    }

    private void createHUD() {
        overlay = new FrameLayout(this);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        View topFade = new View(this);
        topFade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xD9000000, 0x54000000, 0x00000000}));
        FrameLayout.LayoutParams tf = new FrameLayout.LayoutParams(-1, dp(182), Gravity.TOP);
        overlay.addView(topFade, tf);
        View bottomFade = new View(this);
        bottomFade.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xED000000, 0xAE000000, 0x00000000}));
        FrameLayout.LayoutParams bf = new FrameLayout.LayoutParams(-1, dp(310), Gravity.BOTTOM);
        overlay.addView(bottomFade, bf);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams headerLp = new FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP);
        headerLp.setMargins(dp(22), dp(29), dp(22), 0);
        overlay.addView(header, headerLp);
        TextView brandMark = text("g", 26, CORAL, true);
        header.addView(brandMark, new LinearLayout.LayoutParams(dp(30), -2));
        TextView brand = text("GlipsFlow", 21, WHITE, true);
        brand.setLetterSpacing(-.055f);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        focusToggle = text("◫", 24, WHITE, false);
        focusToggle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams focusLp = new LinearLayout.LayoutParams(dp(45), dp(43));
        focusLp.rightMargin = dp(5); header.addView(focusToggle, focusLp);
        focusToggle.setOnClickListener(v -> setFocusMode(!focusMode));
        headerAvatar = new ProfileAvatarView(this, 30);
        headerAvatar.showProfile(store.currentProfile());
        LinearLayout.LayoutParams avatarHeaderParams = new LinearLayout.LayoutParams(dp(43), dp(43));
        header.addView(headerAvatar, avatarHeaderParams);
        headerAvatar.setContentDescription("Open your local profile and photo");
        headerAvatar.setOnClickListener(v -> selectTab(3));

        LinearLayout upper = new LinearLayout(this);
        upper.setGravity(Gravity.CENTER_VERTICAL);
        hudUpper = upper;
        FrameLayout.LayoutParams upperLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        upperLp.setMargins(dp(24), dp(91), dp(24), 0);
        overlay.addView(upper, upperLp);
        profileLabel = text("●  OFFLINE / MY SPACE", 10, CORAL, true);
        profileLabel.setLetterSpacing(.12f);
        profileLabel.setMaxLines(1);
        profileLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        upper.addView(profileLabel, new LinearLayout.LayoutParams(0, -2, 1f));
        profileLabel.setOnClickListener(v -> selectTab(3));
        currentNumber = text("01  /  01", 12, WHITE, true);
        currentNumber.setLetterSpacing(.1f);
        upper.addView(currentNumber);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        hudInfo = info;
        FrameLayout.LayoutParams infoLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        infoLp.setMargins(dp(24), 0, dp(82), dp(154));
        overlay.addView(info, infoLp);
        TextView eyebrow = text("YOUR OWN LITTLE CINEMA  /  NO UPLOADS", 10, CORAL, true);
        eyebrow.setLetterSpacing(.17f);
        info.addView(eyebrow);
        titleText = text("", 34, WHITE, true);
        titleText.setMaxLines(2);
        titleText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(-1, -2);
        tLp.topMargin = dp(9);
        info.addView(titleText, tLp);
        hintText = text("SWIPE UP FOR NEXT VIDEO  ↑", 11, MUTED, false);
        hintText.setLetterSpacing(.045f);
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(-1, -2);
        hLp.topMargin = dp(11);
        info.addView(hintText, hLp);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.VERTICAL);
        tools.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams toolsLp = new FrameLayout.LayoutParams(dp(58), -2, Gravity.RIGHT | Gravity.BOTTOM);
        toolsLp.setMargins(0, 0, dp(14), dp(165));
        overlay.addView(tools, toolsLp);
        favoriteIcon = addTool(tools, "♡", "LIKE", () -> {
            if (current == null) return;
            store.toggleFavorite(store.clips.get(currentIndex));
            favoriteIcon.animate().cancel();
            favoriteIcon.animate().scaleX(1.23f).scaleY(1.23f).setDuration(110)
                    .withEndAction(() -> favoriteIcon.animate().scaleX(1f).scaleY(1f)
                            .setDuration(150).start()).start();
            updateControls();
        });
        // Sound Room now has one intentional entry point, directly below ♥.
        soundIcon = addTool(tools, "≋", "SOUNDS", () -> selectTab(2));
        toolSound = (View) soundIcon.getParent();
        shuffleIcon = addTool(tools, "⤨", "MIX", () -> {
            shuffle = !shuffle; store.setShuffle(shuffle); resetHistory();
            disposePrefetch(); preloadNext(); updateControls();
            toast(shuffle ? "Shuffle on" : "Shuffle off");
        });
        toolShuffle = (View) shuffleIcon.getParent();
        fitIcon = addTool(tools, "⛶", "FIT", () -> {
            fit = !fit; store.setFit(fit);
            if (current != null) current.setFit(fit);
            if (incoming != null) incoming.setFit(fit);
            if (stagedNext != null) stagedNext.setFit(fit);
            updateControls();
        });
        toolFit = (View) fitIcon.getParent();
        muteIcon = addTool(tools, "♫", "SOUND", () -> {
            muted = !muted; store.setMute(muted);
            if (current != null) current.setMuted(muted);
            if (incoming != null) incoming.setMuted(muted);
            if (stagedNext != null) stagedNext.setMuted(muted);
            updateSpectrumSource();
            updateControls();
        });

        toolMute = (View) muteIcon.getParent();
        LinearLayout bottom = new LinearLayout(this);
        hudPlayback = bottom;
        bottom.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bottomLp.setMargins(dp(22), 0, dp(22), dp(90));
        overlay.addView(bottom, bottomLp);
        seekBar = new SeekBar(this);
        seekBar.setMax(1);
        seekBar.setPadding(0, 0, 0, 0);
        seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(accent()));
        seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(accent()));
        seekBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0x55FFFFFF));
        bottom.addView(seekBar, new LinearLayout.LayoutParams(-1, dp(26)));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar bar) { isScrubbing = true; }
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser) timerText.setText(time(progress) + "   /   " + time(current == null ? 0 : current.duration()));
            }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                if (current != null) current.seekTo(bar.getProgress());
                isScrubbing = false;
            }
        });
        LinearLayout footRow = new LinearLayout(this);
        footRow.setGravity(Gravity.CENTER_VERTICAL);
        bottom.addView(footRow, new LinearLayout.LayoutParams(-1, dp(26)));
        TextView word = text("ONLY YOUR VIDEOS   ·   OFFLINE", 10, MUTED, true);
        word.setLetterSpacing(.1f);
        footRow.addView(word, new LinearLayout.LayoutParams(0, -2, 1f));
        timerText = text("00:00   /   00:00", 11, WHITE, false);
        footRow.addView(timerText);

        pauseBadge = text("▶", 29, WHITE, true);
        pauseBadge.setGravity(Gravity.CENTER);
        pauseBadge.setBackground(pill(0x99000000, 0x33FFFFFF, 100, 1));
        FrameLayout.LayoutParams pauseLp = new FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER);
        overlay.addView(pauseBadge, pauseLp);
        pauseBadge.setVisibility(View.GONE);
        overlay.setVisibility(View.GONE);
    }

    /** The Sound Room: a deliberately compact pocket-spectrum with analogue-inspired typography. */
    private void createSpectrumPanel() {
        spectrumPanel = new FrameLayout(this);
        spectrumPanel.setBackground(pill(0xFF282625, 0xFF67605D, 17, 1));
        spectrumPanel.setElevation(dp(10));
        // Mounted inside the dedicated SOUND page, never over the video feed.

        View sideMark = new View(this);
        sideMark.setBackground(pill(accent(), 0, 2, 0));
        FrameLayout.LayoutParams stripeLp = new FrameLayout.LayoutParams(dp(3), dp(46), Gravity.TOP | Gravity.LEFT);
        stripeLp.setMargins(dp(0), dp(19), 0, 0);
        spectrumPanel.addView(sideMark, stripeLp);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(10), dp(11), dp(11));
        spectrumPanel.addView(body, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(heading, new LinearLayout.LayoutParams(-1, dp(24)));
        TextView micro = text("FOUR FREQUENCY WINDOWS", 9, 0xFFABB5B5, true);
        micro.setLetterSpacing(.08f);
        heading.addView(micro, new LinearLayout.LayoutParams(0, -2, 1f));
        spectrumModeLabel = text("TICKS ↗", 10, 0xFFF3C798, true);
        heading.addView(spectrumModeLabel);
        spectrumModeLabel.setContentDescription("Change the Sound Room drawing style");

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(titleRow, new LinearLayout.LayoutParams(-1, dp(31)));
        TextView name = text("sound room", 22, WHITE, true);
        name.setLetterSpacing(-.05f);
        titleRow.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        spectrumFocusLabel = text("ALL 04", 10, 0xFFBDD1C5, true);
        titleRow.addView(spectrumFocusLabel);

        spectrumView = new SoundSpectrumView(this);
        int style = getSharedPreferences("galleryflow_display_v3", MODE_PRIVATE).getInt("visual_style_v4", 0);
        int focus = getSharedPreferences("galleryflow_display_v3", MODE_PRIVATE).getInt("visual_focus_v4", -1);
        spectrumView.setStyle(style);
        spectrumView.setFocus(focus);
        updateSpectrumLabels();
        body.addView(spectrumView, new LinearLayout.LayoutParams(-1, dp(158)));

        TextView footer = text("TAP: DRAWING STYLE   ·   HOLD: FOCUS BAND", 8.5f, 0xFF9CA6A8, true);
        footer.setLetterSpacing(.02f);
        body.addView(footer, new LinearLayout.LayoutParams(-1, dp(17)));
        spectrumPanel.setContentDescription("Sound Room: four approximate audio frequency zones");

        View.OnClickListener nextStyle = v -> {
            spectrumView.setStyle((spectrumView.style() + 1) % 3);
            getSharedPreferences("galleryflow_display_v3", MODE_PRIVATE).edit()
                    .putInt("visual_style_v4", spectrumView.style()).apply();
            updateSpectrumLabels();
        };
        View.OnLongClickListener nextFocus = v -> {
            int next = spectrumView.focus() == 3 ? -1 : spectrumView.focus() + 1;
            spectrumView.setFocus(next);
            getSharedPreferences("galleryflow_display_v3", MODE_PRIVATE).edit()
                    .putInt("visual_focus_v4", next).apply();
            updateSpectrumLabels();
            return true;
        };
        spectrumModeLabel.setOnClickListener(nextStyle);
        spectrumFocusLabel.setOnClickListener(v -> nextFocus.onLongClick(v));
        spectrumView.setOnClickListener(nextStyle);
        spectrumView.setOnLongClickListener(nextFocus);
        soundController = new SoundSpectrumController(spectrumView);
        spectrumPanel.setVisibility(View.GONE);
    }

    private void updateSpectrumLabels() {
        if (spectrumModeLabel != null && spectrumView != null)
            spectrumModeLabel.setText(spectrumView.styleName() + " ↗");
        if (spectrumFocusLabel != null && spectrumView != null)
            spectrumFocusLabel.setText(spectrumView.focus() < 0 ? "ALL 04" : spectrumView.focusName());
    }

    private void toggleSoundVisuals() {
        if (soundEnabled) { setSoundVisuals(false); return; }
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            new AlertDialog.Builder(this)
                    .setTitle(tr("Open Sound Room?"))
                    .setMessage(tr("Android requires audio permission to visualize sound from the video player. "
                            + "GlipsFlow does not record or upload microphone audio. "
                            + "These are visual frequency zones, not isolated instruments."))
                    .setNegativeButton(tr("Not now"), null)
                    .setPositiveButton(tr("Continue"), (d, which) ->
                            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, ASK_SOUND))
                    .show();
            return;
        }
        setSoundVisuals(true);
    }

    private void setSoundVisuals(boolean enable) {
        soundEnabled = enable;
        getSharedPreferences("galleryflow_display_v3", MODE_PRIVATE)
                .edit().putBoolean("audio_visuals", enable).apply();
        spectrumPanel.setVisibility(enable && current != null && selectedTab == 2 ? View.VISIBLE : View.GONE);
        if (selectedTab == 2) renderSoundScreen();
        if (soundIcon != null) soundIcon.setTextColor(enable ? accent() : WHITE);
        updateSpectrumSource();
    }

    private void updateSpectrumSource() {
        if (soundController == null) return;
        boolean canPlay = soundEnabled && selectedTab == 2 && screenActive && wantedPlaying && !muted
                && current != null && current.isPlaying()
                && hasPermission(Manifest.permission.RECORD_AUDIO);
        if (!canPlay) { soundController.detach(); return; }
        if (!soundController.attach(current.audioSessionId())) {
            // Some devices restrict output-session capture. Video playback is unaffected.
            soundController.detach();
        }
    }

    private TextView addTool(LinearLayout parent, String glyph, String caption, Runnable action) {
        LinearLayout item = new LinearLayout(this);
        item.setGravity(Gravity.CENTER_HORIZONTAL);
        item.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(62));
        parent.addView(item, lp);
        TextView icon = text(glyph, 25, WHITE, false);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(pill(0x65000000, 0x44FFFFFF, 100, 1));
        item.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));
        TextView label = text(caption, 8.5f, WHITE, true);
        label.setGravity(Gravity.CENTER);
        label.setLetterSpacing(.1f);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = dp(2);
        item.addView(label, labelLp);
        item.setOnClickListener(v -> action.run());
        item.setContentDescription(tr(caption));
        return icon;
    }

    private void createEmptyState() {
        empty = new FrameLayout(this);
        empty.setBackgroundColor(NIGHT);
        root.addView(empty, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.LEFT);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL);
        lp.setMargins(dp(28), dp(0), dp(28), 0);
        empty.addView(content, lp);

        TextView mini = text("YOUR FILM ROLL   /   PRIVATE COLLECTION", 11, CORAL, true);
        mini.setLetterSpacing(.1f);
        content.addView(mini);
        emptyTitle = text("A cinema\nof your own.", 44, WHITE, true);
        TextView headline = emptyTitle;
        headline.setLineSpacing(-dp(4), 1f);
        headline.setLetterSpacing(-.06f);
        LinearLayout.LayoutParams h = new LinearLayout.LayoutParams(-1, -2);
        h.topMargin = dp(22);
        content.addView(headline, h);
        emptyDescription = text("Allow video access to build your private feed.\nNo account. No uploads. Just your gallery.", 15, MUTED, false);
        TextView desc = emptyDescription;
        desc.setLineSpacing(dp(5), 1f);
        LinearLayout.LayoutParams d = new LinearLayout.LayoutParams(-1, -2);
        d.topMargin = dp(22); content.addView(desc, d);
        emptyButton = text("ALLOW VIDEO ACCESS    ↗", 14, NIGHT, true);
        TextView button = emptyButton;
        button.setGravity(Gravity.CENTER);
        button.setLetterSpacing(.04f);
        button.setBackground(pill(CORAL, CORAL, 18, 0));
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(-1, dp(60));
        b.topMargin = dp(34); content.addView(button, b);
        button.setOnClickListener(v -> {
            if (hasVideoAccess() && isFullAccess()) refreshGallery();
            else requestVideoAccess();
        });
        TextView note = text("VIDEOS STAY ON YOUR PHONE · LOCAL ONLY", 10, 0xFF87898F, true);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams n = new LinearLayout.LayoutParams(-1, -2);
        n.topMargin = dp(22); content.addView(note, n);

        TextView top = text("g  GlipsFlow                          ◉ YOU", 16, WHITE, true);
        top.setOnClickListener(v -> selectTab(3));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        tl.setMargins(dp(24), dp(37), dp(20), 0);
        empty.addView(top, tl);
        TextView bottom = text("BUILT FOR YOUR CAMERA ROLL.     ↗", 11, 0xFF8D9199, true);
        bottom.setLetterSpacing(.06f);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bl.setMargins(dp(28), 0, dp(24), dp(96));
        empty.addView(bottom, bl);
    }

    private void showEmpty() {
        if (headerAvatar != null && store != null) headerAvatar.showProfile(store.currentProfile());
        if (emptyTitle != null) {
            boolean granted = hasVideoAccess();
            emptyTitle.setText(granted ? "Your gallery.\nYour feed." : "A cinema\nof your own.");
            emptyDescription.setText(granted
                    ? "No videos found in the accessible gallery.\nYou can refresh or select more videos in Android settings."
                    : "Give GlipsFlow access to videos on your phone.\nNothing is uploaded and no login is needed.");
            emptyButton.setText(granted ? (isFullAccess() ? "REFRESH GALLERY    ↻" : "CHOOSE MORE VIDEOS    ↗")
                    : "ALLOW VIDEO ACCESS    ↗");
        }
        empty.setVisibility(View.VISIBLE);
        if (spectrumPanel != null) spectrumPanel.setVisibility(View.GONE);
        if (soundController != null) soundController.detach();
        if (ambientGlow != null) { ambientGlow.setVisibility(View.GONE); ambientGlow.reset(); }
        overlay.setVisibility(View.GONE);
        tapArea.setVisibility(View.GONE);
        disposeAllPages();
        if (selectedTab == 1) renderShelfScreen();
        else if (selectedTab == 2) renderSoundScreen();
        else if (selectedTab == 3) renderProfileScreen();
    }

    private void showClip(int idx) {
        if (idx < 0 || idx >= store.clips.size()) { showEmpty(); return; }
        empty.setVisibility(View.GONE); overlay.setVisibility(View.VISIBLE); tapArea.setVisibility(View.VISIBLE);
        disposeAllPages();
        if (spectrumPanel != null) spectrumPanel.setVisibility(soundEnabled && selectedTab == 2 ? View.VISIBLE : View.GONE);
        currentIndex = idx; store.saveIndex(idx);
        lastAmbientSample = 0L;
        if (ambientGlow != null) ambientGlow.reset();
        current = makePage(idx);
        stage.addView(current, new FrameLayout.LayoutParams(-1, -1));
        current.setActive(wantedPlaying && (selectedTab == 0 || selectedTab == 2));
        updateHud();
        stage.postDelayed(this::preloadNext, 120);
    }

    private VideoPage makePage(int idx) {
        return new VideoPage(this, store.clips.get(idx), this, muted, fit);
    }

    private void disposeAllPages() {
        if (soundController != null) soundController.detach();
        isAnimating = false;
        if (current != null) current.release();
        if (incoming != null) incoming.release();
        if (stagedNext != null) stagedNext.release();
        current = null; incoming = null; stagedNext = null;
        stagedNextIndex = -1; incomingIndex = -1;
        stage.removeAllViews();
    }

    private void updateHud() {
        if (currentIndex < 0 || currentIndex >= store.clips.size()) return;
        Clip showing = store.clips.get(currentIndex);
        rawText(titleText, showing.title);
        if (profileLabel != null) profileLabel.setText("●  PRIVATE / " + store.currentProfile().name.toUpperCase(Locale.getDefault()));
        if (headerAvatar != null) headerAvatar.showProfile(store.currentProfile());
        currentNumber.setText(String.format(java.util.Locale.US, "%02d  /  %02d", currentIndex + 1, store.clips.size()));
        hintText.setText("LATEST FIRST  ·  " + readableDate(showing.addedAtMillis) + "  ·  SWIPE ↑");
        seekBar.setProgress(0);
        updateControls();
    }

    private void updateControls() {
        if (store.clips.isEmpty()) return;
        favoriteIcon.setText(store.isFavorite(store.clips.get(currentIndex)) ? "♥" : "♡");
        favoriteIcon.setTextColor(store.isFavorite(store.clips.get(currentIndex)) ? accent() : WHITE);
        shuffleIcon.setTextColor(shuffle ? accent() : WHITE);
        muteIcon.setText(muted ? "♩" : "♫");
        muteIcon.setTextColor(muted ? 0xFF999CA4 : WHITE);
        fitIcon.setTextColor(fit ? accent() : WHITE);
        if (soundIcon != null) soundIcon.setTextColor(soundEnabled ? accent() : WHITE);
    }

    private boolean hasPermission(String name) {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(name) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isFullAccess() {
        if (Build.VERSION.SDK_INT >= 33) return hasPermission(Manifest.permission.READ_MEDIA_VIDEO);
        return hasPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
    }

    private boolean hasVideoAccess() {
        if (isFullAccess()) return true;
        return Build.VERSION.SDK_INT >= 34 &&
                hasPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
    }

    private void requestVideoAccess() {
        if (Build.VERSION.SDK_INT < 23) { refreshGallery(); return; }
        if (Build.VERSION.SDK_INT >= 34) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}, ASK_VIDEOS);
        } else if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO}, ASK_VIDEOS);
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, ASK_VIDEOS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == ASK_VIDEOS) {
            if (hasVideoAccess()) refreshGallery();
            else { showEmpty(); toast("Video permission not granted"); }
        } else if (requestCode == ASK_SOUND) {
            if (hasPermission(Manifest.permission.RECORD_AUDIO)) setSoundVisuals(true);
            else toast("Sound waves stay off without audio permission");
        }
    }

    /** Runs the MediaStore query off the UI thread; a new scan replaces stale metadata. */
    private void refreshGallery() {
        if (!hasVideoAccess()) { showEmpty(); return; }
        if (scanBusy) { scanPending = true; return; }
        scanBusy = true;
        if (current == null && emptyTitle != null) {
            emptyTitle.setText("Finding your\nvideos...");
            emptyDescription.setText("Scanning the videos Android lets GlipsFlow access.\nNothing is copied or uploaded.");
            emptyButton.setText("SCANNING GALLERY  ↻");
        }
        scanWorker.execute(() -> {
            ArrayList<Clip> scanned;
            boolean failed = false;
            try { scanned = MediaGallery.findVideos(getApplicationContext()); }
            catch (Exception ex) { scanned = new ArrayList<>(); failed = true; }
            ArrayList<Clip> result = scanned;
            boolean error = failed;
            handler.post(() -> {
                if (alreadyDestroyed || isFinishing() || isDestroyed()) return;
                scanBusy = false;
                if (error) {
                    if (current == null) showEmpty();
                    toast("Could not read the gallery. Check video access.");
                } else applyGallery(result);
                if (scanPending) { scanPending = false; refreshGallery(); }
            });
        });
    }

    private void applyGallery(ArrayList<Clip> scanned) {
        String keepKey = current == null ? null : current.clip.key();
        boolean changed = store.clips.size() != scanned.size();
        if (!changed) for (int i = 0; i < scanned.size(); i++) {
            if (!store.clips.get(i).key().equals(scanned.get(i).key()) ||
                    store.clips.get(i).sizeBytes != scanned.get(i).sizeBytes) {
                changed = true; break;
            }
        }
        if (!changed && current != null) return;
        store.setGallery(scanned);
        if (scanned.isEmpty()) { resetHistoryTo(0); showEmpty(); return; }
        int idx = -1;
        if (keepKey != null) for (int i = 0; i < scanned.size(); i++) {
            if (scanned.get(i).key().equals(keepKey)) { idx = i; break; }
        }
        if (idx < 0) idx = current == null
                ? Math.max(0, Math.min(store.savedIndex(), scanned.size() - 1)) : 0;
        resetHistoryTo(idx);
        wantedPlaying = true;
        showClip(idx);
        if (selectedTab == 1) renderShelfScreen();
        if (selectedTab == 2) renderSoundScreen();
        if (selectedTab == 3) renderProfileScreen();
        if (!isFullAccess()) toast("Showing only the videos you allowed");
    }

    private String readableDate(long when) {
        if (when <= 0) return "DATE UNKNOWN";
        return new SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(new Date(when));
    }

    /** User-selectable typography, stored only on this device. */
    private void loadFontSettings() {
        fontStyle = getSharedPreferences(FONT_SETTINGS, MODE_PRIVATE)
                .getString("style", "Studio");
        File local = new File(getFilesDir(), FONT_LOCAL_FILE);
        if (local.isFile()) {
            try { customTypeface = Typeface.createFromFile(local); }
            catch (RuntimeException ignored) { customTypeface = null; }
        }
        if ("Custom".equals(fontStyle) && customTypeface == null) fontStyle = "Studio";
    }

    private Typeface fontFor(int style) {
        Typeface family;
        switch (fontStyle) {
            case "Editorial": family = Typeface.SERIF; break;
            case "Narrow": family = Typeface.create("sans-serif-condensed", Typeface.NORMAL); break;
            case "Mono": family = Typeface.MONOSPACE; break;
            case "Soft": family = Typeface.create("casual", Typeface.NORMAL); break;
            case "Custom": family = customTypeface != null ? customTypeface : Typeface.SANS_SERIF; break;
            default: family = Typeface.SANS_SERIF;
        }
        return Typeface.create(family, style);
    }

    private void setFontStyle(String choice) {
        if ("Custom".equals(choice) && customTypeface == null) {
            toast("Choose a TTF or OTF font first"); return;
        }
        fontStyle = choice;
        getSharedPreferences(FONT_SETTINGS, MODE_PRIVATE).edit().putString("style", choice).apply();
        // Update existing controls; freshly rendered pages use the selection in text().
        applyFontToTree(root);
        if (selectedTab == 3) renderProfileScreen();
        updateNavigation();
    }

    private void applyFontToTree(View element) {
        if (element instanceof TextView) {
            TextView label = (TextView) element;
            Typeface former = label.getTypeface();
            int style = former == null ? Typeface.NORMAL : former.getStyle();
            label.setTypeface(fontFor(style));
        }
        if (element instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) element;
            for (int i = 0; i < group.getChildCount(); i++) applyFontToTree(group.getChildAt(i));
        }
    }

    private void chooseFontStyle() {
        String[] choices = {
            tr("Studio  /  clean sans"), tr("Editorial  /  classic serif"),
            tr("Narrow  /  condensed"), tr("Mono  /  typewriter"),
            tr("Soft  /  informal"), tr("Custom  /  import TTF or OTF")
        };
        new AlertDialog.Builder(this)
            .setTitle(tr("Choose your type"))
            .setSingleChoiceItems(choices, fontIndex(), (dialog, item) -> {
                dialog.dismiss();
                if (item == 5) chooseFontFile();
                else setFontStyle(FONT_STYLES[item]);
            })
            .setNegativeButton(tr("Cancel"), null).show();
    }

    private int fontIndex() {
        for (int i = 0; i < FONT_STYLES.length; i++)
            if (FONT_STYLES[i].equals(fontStyle)) return i;
        return 0;
    }

    private void chooseFontFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*"); // Some Android file providers do not advertise font MIME types.
        try { startActivityForResult(intent, PICK_FONT); }
        catch (Exception ex) { toast("Cannot open file picker"); }
    }

    private void importFont(Uri uri) {
        String fileName = "";
        try (Cursor cursor = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) fileName = cursor.getString(0);
        } catch (Exception ignored) { }
        if (fileName == null || !(fileName.toLowerCase(Locale.US).endsWith(".ttf") ||
                fileName.toLowerCase(Locale.US).endsWith(".otf"))) {
            toast("Please choose a .ttf or .otf font file"); return;
        }
        scanWorker.execute(() -> {
            File staged = new File(getFilesDir(), "galleryflow_font.pending");
            File target = new File(getFilesDir(), FONT_LOCAL_FILE);
            File backup = new File(getFilesDir(), "galleryflow_font.previous");
            boolean ok = false;
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(staged)) {
                if (in == null) throw new java.io.IOException("Font unavailable");
                byte[] buffer = new byte[8192];
                long total = 0;
                int n;
                while ((n = in.read(buffer)) != -1) {
                    total += n;
                    if (total > 8L * 1024 * 1024) throw new java.io.IOException("Font exceeds 8MB");
                    out.write(buffer, 0, n);
                }
                out.flush();
                Typeface.createFromFile(staged); // Reject invalid font data.
                if (backup.exists()) backup.delete();
                if (target.exists() && !target.renameTo(backup))
                    throw new java.io.IOException("Cannot preserve previous font");
                if (!staged.renameTo(target)) {
                    if (backup.exists()) backup.renameTo(target);
                    throw new java.io.IOException("Cannot save imported font");
                }
                backup.delete();
                ok = true;
            } catch (Exception ignored) { }
            finally { staged.delete(); }
            boolean success = ok;
            handler.post(() -> {
                if (alreadyDestroyed) return;
                if (success) {
                    try {
                        customTypeface = Typeface.createFromFile(target);
                        setFontStyle("Custom");
                        toast("Your font is ready");
                    } catch (Exception ignored) { toast("Could not load the selected font"); }
                } else toast("Could not import font (TTF/OTF, up to 8MB)");
            });
        });
    }

    private String humanBytes(long bytes) {
        if (bytes < 0) return "—";
        double size = (double) bytes;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unit = 0;
        while (size >= 1024.0 && unit < 4) { size /= 1024.0; unit++; }
        return String.format(Locale.US, "%.1f %s", size, units[unit]);
    }

    private long availableStorageBytes() {
        try {
            File primary = getExternalFilesDir(null);
            if (primary == null) primary = getFilesDir();
            return new StatFs(primary.getAbsolutePath()).getAvailableBytes();
        } catch (Exception ex) { return -1L; }
    }

    private long totalStorageBytes() {
        try {
            File primary = getExternalFilesDir(null);
            if (primary == null) primary = getFilesDir();
            return new StatFs(primary.getAbsolutePath()).getTotalBytes();
        } catch (Exception ex) { return -1L; }
    }

    private void addStorageSummary(LinearLayout body) {
        long videos = 0L;
        for (Clip clip : store.clips) {
            if (Long.MAX_VALUE - videos < clip.sizeBytes) { videos = Long.MAX_VALUE; break; }
            videos += clip.sizeBytes;
        }
        long total = totalStorageBytes();
        long free = availableStorageBytes();
        TextView label = text("STORAGE  /  THIS DEVICE", 10, 0xFF686C62, true);
        label.setLetterSpacing(.14f);
        LinearLayout.LayoutParams title = new LinearLayout.LayoutParams(-1, -2);
        title.topMargin = dp(24); title.bottomMargin = dp(11); body.addView(label, title);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(16), dp(16), dp(17));
        panel.setBackground(pill(WHITE, 0xFFD6D8D4, 16, 1));
        body.addView(panel, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout figures = new LinearLayout(this);
        figures.setOrientation(LinearLayout.HORIZONTAL);
        panel.addView(figures, new LinearLayout.LayoutParams(-1, -2));
        addStorageFigure(figures, "DEVICE TOTAL", humanBytes(total));
        addStorageFigure(figures, "YOUR VIDEOS", humanBytes(videos));
        addStorageFigure(figures, "SPACE LEFT", humanBytes(free));
        StorageBarView meter = new StorageBarView(this, total, free, videos, accent(), darkPaper());
        LinearLayout.LayoutParams meterLp = new LinearLayout.LayoutParams(-1, dp(21));
        meterLp.topMargin = dp(16); meterLp.bottomMargin = dp(11);
        panel.addView(meter, meterLp);
        LinearLayout keys = new LinearLayout(this);
        keys.setGravity(Gravity.CENTER_VERTICAL);
        panel.addView(keys, new LinearLayout.LayoutParams(-1, -2));
        storageKey(keys, "●  VIDEOS", accent(), 1f);
        storageKey(keys, "●  OTHER USED", darkPaper() ? 0xFFB3C0BE : INK, 1.2f);
        storageKey(keys, "●  FREE", darkPaper() ? 0xFFB0B9BA : 0xFF898E8A, .8f);
        TextView footnote = text(isFullAccess()
                        ? "Bar uses this phone's primary storage. Video bytes are an estimate from readable clips."
                        : "Bar uses this phone's primary storage. Video size includes only clips you allowed.",
                10, 0xFF686C62, false);
        footnote.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(11); body.addView(footnote, fp);
    }

    private void storageKey(LinearLayout row, String title, int color, float weight) {
        TextView legend = text(title, 9, color, true);
        legend.setSingleLine(true);
        legend.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(legend, new LinearLayout.LayoutParams(0, -2, weight));
    }

    private void addStorageFigure(LinearLayout card, String caption, String amount) {
        LinearLayout segment = new LinearLayout(this);
        segment.setOrientation(LinearLayout.VERTICAL);
        card.addView(segment, new LinearLayout.LayoutParams(0, -2, 1));
        TextView figure = text(amount, 22, INK, true);
        figure.setSingleLine(true); figure.setTextSize(21);
        segment.addView(figure);
        TextView small = text(caption, 9, 0xFF77766F, true);
        small.setLetterSpacing(.10f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(9); segment.addView(small, lp);
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }
    private final class LocalizedTextView extends TextView {
        LocalizedTextView(MainActivity context) { super(context); }
        @Override public void setText(CharSequence value, BufferType type) {
            super.setText(value == null ? null : tr(value.toString()), type);
        }
        void raw(String unmodified) { super.setText(unmodified, BufferType.NORMAL); }
    }
    private void rawText(TextView view, String title) {
        if (view instanceof LocalizedTextView) ((LocalizedTextView)view).raw(title);
        else view.setText(title);
    }
    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new LocalizedTextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(palette(color));
        t.setIncludeFontPadding(false);
        t.setFontFeatureSettings("kern");
        t.setTypeface(fontFor(bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }
    private GradientDrawable pill(int fill, int stroke, int radiusDp, int strokeDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(surface(fill));
        gd.setCornerRadius(dp(radiusDp));
        if (strokeDp != 0) gd.setStroke(dp(strokeDp), surface(stroke));
        return gd;
    }
    private String time(int millis) {
        int total = Math.max(0, millis / 1000);
        return String.format(java.util.Locale.US, "%02d:%02d", total / 60, total % 60);
    }
    private void toast(String s) { Toast.makeText(this, tr(s), Toast.LENGTH_SHORT).show(); }

    private boolean handleSwipe(View view, MotionEvent event) {
        if (current == null || isAnimating) return true;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchDownY = event.getY(); touchDownX = event.getX();
                isDragging = false; direction = 0;
                return true;
            case MotionEvent.ACTION_MOVE:
                float delta = event.getY() - touchDownY;
                float dx = event.getX() - touchDownX;
                if (!isDragging && Math.abs(delta) > dp(14) && Math.abs(delta) > Math.abs(dx) * 1.2f) isDragging = true;
                if (!isDragging) return true;
                int newDirection = delta < 0 ? 1 : -1;
                if (newDirection != direction) {
                    discardIncoming(); direction = newDirection;
                    int target = getCandidate(direction);
                    if (target >= 0) {
                        if (direction == 1 && stagedNext != null && stagedNextIndex == target) {
                            incoming = stagedNext; stagedNext = null; stagedNextIndex = -1;
                        } else {
                            disposePrefetch();
                            incoming = makePage(target);
                            stage.addView(incoming, 0, new FrameLayout.LayoutParams(-1, -1));
                        }
                        incomingIndex = target;
                    }
                }
                if (incoming == null) return true;
                float h = stage.getHeight();
                float bounded = Math.max(-h, Math.min(h, delta));
                current.setTranslationY(bounded);
                incoming.setTranslationY(bounded + (direction == 1 ? h : -h));
                return true;
            case MotionEvent.ACTION_UP:
                float travel = event.getY() - touchDownY;
                if (!isDragging && Math.abs(travel) < dp(12) && Math.abs(event.getX() - touchDownX) < dp(12)) {
                    togglePlayback();
                    return true;
                }
                if (incoming != null && Math.abs(travel) > stage.getHeight() * .17f) {
                    finishSwipe(true);
                } else finishSwipe(false);
                return true;
            case MotionEvent.ACTION_CANCEL:
                finishSwipe(false);
                return true;
        }
        return true;
    }

    private int getCandidate(int dir) {
        if (store.clips.size() < 2) return -1;
        if (!shuffle) return (currentIndex + dir + store.clips.size()) % store.clips.size();
        if (dir < 0) return historyPos > 0 ? history.get(historyPos - 1) : -1;
        if (historyPos + 1 < history.size()) return history.get(historyPos + 1);
        if (pendingRandom != -1) return pendingRandom;
        int candidate = random.nextInt(store.clips.size() - 1);
        pendingRandom = candidate >= currentIndex ? candidate + 1 : candidate;
        return pendingRandom;
    }

    private void resetHistory() { resetHistoryTo(currentIndex); }
    private void resetHistoryTo(int idx) {
        history.clear(); history.add(idx); historyPos = 0; pendingRandom = -1;
    }

    private void finishSwipe(boolean accepted) {
        if (incoming == null) {
            current.animate().translationY(0).setDuration(150).start();
            if (isDragging && store.clips.size() < 2) toast("Add more videos to keep swiping");
            return;
        }
        final VideoPage old = current;
        final VideoPage next = incoming;
        final int nextIndex = incomingIndex;
        final int dir = direction;
        final float h = stage.getHeight();
        isAnimating = true;
        if (accepted) {
            if (soundController != null) soundController.detach();
            old.setActive(false);
            next.setActive(wantedPlaying);
            old.animate().translationY(dir == 1 ? -h : h).setDuration(190).start();
            next.animate().translationY(0).setDuration(190).withEndAction(() -> {
                if (isFinishing() || isDestroyed()) return;
                stage.removeView(old); old.release();
                current = next; incoming = null; incomingIndex = -1;
                lastAmbientSample = 0L;
                if (ambientGlow != null) ambientGlow.reset();
                currentIndex = nextIndex; store.saveIndex(currentIndex); pendingRandom = -1;
                if (shuffle) {
                    if (dir < 0 && historyPos > 0) historyPos--;
                    else if (dir > 0) {
                        if (historyPos + 1 < history.size()) historyPos++;
                        else { history.add(currentIndex); historyPos = history.size() - 1; }
                    }
                }
                current.setActive(wantedPlaying && (selectedTab == 0 || selectedTab == 2));
                isAnimating = false; isDragging = false;
                updateHud();
                updateSpectrumSource();
                preloadNext();
            }).start();
        } else {
            old.animate().translationY(0).setDuration(180).start();
            next.animate().translationY(dir == 1 ? h : -h).setDuration(180).withEndAction(() -> {
                if (next == incoming) { stage.removeView(next); next.release(); incoming = null; incomingIndex = -1; }
                isAnimating = false; isDragging = false; preloadNext();
            }).start();
        }
    }

    private void discardIncoming() {
        if (incoming != null) { stage.removeView(incoming); incoming.release(); incoming = null; incomingIndex = -1; }
        if (current != null) current.setTranslationY(0);
    }
    private void disposePrefetch() {
        if (stagedNext != null) { stage.removeView(stagedNext); stagedNext.release(); stagedNext = null; stagedNextIndex = -1; }
    }
    private void preloadNext() {
        if (current == null || incoming != null || isAnimating || isDragging || stage.getHeight() == 0) return;
        int target = getCandidate(1);
        if (target < 0) { disposePrefetch(); return; }
        if (stagedNext != null && stagedNextIndex == target) {
            stagedNext.setTranslationY(stage.getHeight());
            return;
        }
        disposePrefetch();
        stagedNextIndex = target;
        stagedNext = makePage(target);
        stage.addView(stagedNext, 0, new FrameLayout.LayoutParams(-1, -1));
        stagedNext.setTranslationY(stage.getHeight());
    }

    private void togglePlayback() {
        if (current == null) return;
        wantedPlaying = !wantedPlaying;
        current.setActive(wantedPlaying && (selectedTab == 0 || selectedTab == 2));
        updateSpectrumSource();
        pauseBadge.setText(wantedPlaying ? "▶" : "Ⅱ");
        pauseBadge.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hidePause);
        if (wantedPlaying) handler.postDelayed(hidePause, 600);
    }
    private final Runnable hidePause = () -> { if (pauseBadge != null) pauseBadge.setVisibility(View.GONE); };

    @Override public void onReady(VideoPage page) {
        if (page == current) {
            seekBar.setMax(Math.max(1, current.duration()));
            updateSpectrumSource();
        }
    }
    @Override public void onProblem(VideoPage page) {
        if (page == current) toast("This video can't be played. Swipe to the next clip.");
    }

    // -------- Pocket Cinema: four native destinations; video and files stay local --------
    private TextView editorial(String text, int size, int color, boolean bold) {
        TextView label = text(text, size, color, bold);
        if (size >= 30) label.setLetterSpacing(-.06f);
        return label;
    }

    private void createNavigation() {
        navigation = new LinearLayout(this);
        navigation.setGravity(Gravity.CENTER_VERTICAL);
        navigation.setPadding(dp(12), dp(7), dp(12), dp(9));
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM);
        root.addView(navigation, params);
        String[] symbols = {"▷", "▦", "◎"};
        String[] labels = {"WATCH", "SHELF", "YOU"};
        for (int i = 0; i < NAV_TABS.length; i++) {
            final int page = NAV_TABS[i];
            LinearLayout item = new LinearLayout(this);
            item.setGravity(Gravity.CENTER);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setContentDescription(tr(labels[i]));
            TextView mark = text(symbols[i], 23, WHITE, false);
            mark.setGravity(Gravity.CENTER);
            item.addView(mark, new LinearLayout.LayoutParams(-1, dp(31)));
            TextView name = text(labels[i], 9, MUTED, true);
            name.setGravity(Gravity.CENTER);
            name.setLetterSpacing(.12f);
            item.addView(name, new LinearLayout.LayoutParams(-1, dp(18)));
            navItems[i] = name;
            navigation.addView(item, new LinearLayout.LayoutParams(0, -1, 1));
            item.setOnClickListener(v -> selectTab(page));
        }
        updateNavigation();
    }

    private void updateNavigation() {
        if (navigation == null) return;
        boolean light = selectedTab == 1 || selectedTab == 3;
        navigation.setBackgroundColor(light ? 0xFF232323 : 0xFF101010);
        for (int i = 0; i < navItems.length; i++) {
            if (navItems[i] == null) continue;
            boolean selected = NAV_TABS[i] == selectedTab;
            navItems[i].setTextColor(selected ? accent() : 0xFFC7C6BA);
            View icon = ((LinearLayout) navItems[i].getParent()).getChildAt(0);
            if (icon instanceof TextView) ((TextView) icon).setTextColor(selected ? accent() : WHITE);
            navItems[i].setTypeface(fontFor(selected ? Typeface.BOLD : Typeface.NORMAL));
        }
    }

    private void selectTab(int tab) {
        if (tab < 0 || tab > 3 || isAnimating) return;
        selectedTab = tab;
        if (tab == 0 || tab == 2) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        updateNavigation();
        if (spectrumPanel != null && spectrumPanel.getParent() instanceof ViewGroup) {
            ((ViewGroup) spectrumPanel.getParent()).removeView(spectrumPanel);
        }
        sectionHost.removeAllViews();
        if (tab == 0) sectionHost.setVisibility(View.GONE);
        else {
            sectionHost.setVisibility(View.VISIBLE);
            if (tab == 1) renderShelfScreen();
            else if (tab == 2) renderSoundScreen();
            else renderProfileScreen();
        }
        if (current != null) current.setActive(wantedPlaying && screenActive && (tab == 0 || tab == 2));
        if (tab != 2 && soundController != null) soundController.detach();
        updateSpectrumSource();
        if (ambientGlow != null) ambientGlow.setVisibility(ambientEnabled && tab == 0 ? View.VISIBLE : View.GONE);
    }

    private LinearLayout createPaperPage(int background) {
        LinearLayout screen = new LinearLayout(this);
        screen.setBackgroundColor(surface(background));
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(21), dp(36), dp(21), dp(78));
        sectionHost.addView(screen, new FrameLayout.LayoutParams(-1, -1));
        return screen;
    }

    private void addSectionHeading(LinearLayout container, String kicker, String title,
                                   String description, boolean dark) {
        int major = dark ? WHITE : INK;
        int minor = dark ? MUTED : 0xFF77796D;
        TextView label = editorial(kicker, 10, dark ? CORAL : RUST, true);
        label.setLetterSpacing(.18f);
        container.addView(label);
        TextView headline = editorial(title, 40, major, true);
        headline.setLineSpacing(-dp(7), 1f);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-1, -2);
        hlp.topMargin = dp(13); container.addView(headline, hlp);
        TextView sub = editorial(description, 12, minor, false);
        sub.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = dp(9); container.addView(sub, slp);
    }

    private TextView actionChip(String word, boolean selected, boolean light) {
        if (light && darkPaper()) {
            TextView chip = text(word, 11, selected ? NIGHT : WHITE, true);
            chip.setGravity(Gravity.CENTER);
            chip.setBackground(pill(selected ? accent() : 0xFF303739,
                    selected ? 0 : 0xFF525C5D, 12, selected ? 0 : 1));
            return chip;
        }
        TextView chip = text(word, 11, selected ? (light ? WHITE : NIGHT) : (light ? INK : WHITE), true);
        chip.setGravity(Gravity.CENTER);
        chip.setBackground(pill(selected ? (light ? INK : CORAL) : (light ? 0xFFF5F2EA : 0xFF303830),
                selected ? 0 : (light ? 0xFFCCC8BC : 0xFF4B554B), 12, selected ? 0 : 1));
        return chip;
    }

    private void renderShelfScreen() {
        if (selectedTab != 1 || sectionHost == null) return;
        sectionHost.removeAllViews();
        LinearLayout screen = createPaperPage(PAPER);
        addSectionHeading(screen, "YOUR CAMERA ROLL     /     02", "the film shelf.",
                "Newest clips first · all files stay on this phone", false);
        LinearLayout filters = new LinearLayout(this);
        filters.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, dp(48));
        flp.topMargin = dp(19); screen.addView(filters, flp);
        TextView all = actionChip("ALL FILMS", !shelfLikedOnly, true);
        filters.addView(all, new LinearLayout.LayoutParams(0, dp(42), 1));
        all.setOnClickListener(v -> { shelfLikedOnly = false; renderShelfScreen(); });
        TextView liked = actionChip("♥  KEEPERS", shelfLikedOnly, true);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, dp(42), 1);
        llp.leftMargin = dp(7); filters.addView(liked, llp);
        liked.setOnClickListener(v -> { shelfLikedOnly = true; renderShelfScreen(); });
        TextView refresh = actionChip("↻", false, true);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(46), dp(42));
        rlp.leftMargin = dp(7); filters.addView(refresh, rlp);
        refresh.setOnClickListener(v -> refreshGallery());

        ArrayList<Integer> positions = new ArrayList<>();
        for (int i = 0; i < store.clips.size(); i++)
            if (!shelfLikedOnly || store.isFavorite(store.clips.get(i))) positions.add(i);
        TextView count = text(positions.size() + " VIDEOS  /  " + (shelfLikedOnly ? "SAVED BY " + store.currentProfile().name : "NEWEST FIRST"),
                10, 0xFF77776F, true);
        count.setLetterSpacing(.09f);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(32));
        clp.topMargin = dp(9); screen.addView(count, clp);
        if (positions.isEmpty()) {
            TextView note = editorial(store.clips.isEmpty() ? "No videos yet.\nAllow gallery access to get started."
                            : "Your shelf is empty.\nTap ♥ on a film to keep it here.", 19, INK, true);
            note.setGravity(Gravity.CENTER); note.setLineSpacing(dp(6), 1f);
            note.setBackground(pill(0xFFE2DED2, 0xFFCAC5B7, 14, 1));
            screen.addView(note, new LinearLayout.LayoutParams(-1, 0, 1));
            TextView permission = actionChip(store.clips.isEmpty() ? "GALLERY ACCESS ↗" : "WATCH FILMS ↗", true, true);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, dp(45));
            plp.topMargin = dp(12); screen.addView(permission, plp);
            permission.setOnClickListener(v -> {
                if (store.clips.isEmpty()) { if (hasVideoAccess()) refreshGallery(); else requestVideoAccess(); }
                else selectTab(0);
            });
            return;
        }
        GridView grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dp(7)); grid.setVerticalSpacing(dp(9));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setClipToPadding(false); grid.setVerticalScrollBarEnabled(false);
        screen.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        int cellWidth = (getResources().getDisplayMetrics().widthPixels - dp(42 + 14)) / 3;
        int cellHeight = (int) (cellWidth * 1.6f) + dp(23);
        grid.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return positions.size(); }
            @Override public Object getItem(int pos) { return store.clips.get(positions.get(pos)); }
            @Override public long getItemId(int pos) { return positions.get(pos); }
            @Override public View getView(int pos, View convertView, ViewGroup parent) {
                // GridView recycles cells instead of constructing the whole camera roll.
                FrameLayout card;
                ImageView image;
                TextView title;
                if (convertView instanceof FrameLayout && convertView.getTag() instanceof Object[]) {
                    card = (FrameLayout) convertView;
                    Object[] parts = (Object[]) card.getTag();
                    image = (ImageView) parts[0]; title = (TextView) parts[1];
                } else {
                    card = new FrameLayout(MainActivity.this);
                    card.setBackground(pill(0xFFD3CFC3, 0, 9, 0));
                    card.setClipToOutline(true);
                    image = new ImageView(MainActivity.this);
                    image.setBackgroundColor(surface(0xFFD3CFC3));
                    image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    card.addView(image, new FrameLayout.LayoutParams(-1, cellHeight - dp(23), Gravity.TOP));
                    title = text("", 10, INK, true);
                    title.setSingleLine(true);
                    title.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    title.setGravity(Gravity.CENTER_VERTICAL);
                    title.setPadding(dp(5), 0, dp(4), 0);
                    title.setBackgroundColor(surface(0xFFE2DFD6));
                    card.addView(title, new FrameLayout.LayoutParams(-1, dp(23), Gravity.BOTTOM));
                    card.setTag(new Object[]{image, title});
                }
                Clip item = store.clips.get(positions.get(pos));
                rawText(title, (store.isFavorite(item) ? "♥ " : "") + item.title);
                ThumbnailLoader.load(MainActivity.this, item, image);
                card.setLayoutParams(new android.widget.AbsListView.LayoutParams(-1, cellHeight));
                card.setContentDescription("Watch " + item.title);
                return card;
            }
        });
        grid.setOnItemClickListener((parent, view, pos, id) -> {
            int index = positions.get(pos);
            selectTab(0);
            resetHistoryTo(index);
            wantedPlaying = true;
            showClip(index);
        });
    }

    private void renderSoundScreen() {
        if (selectedTab != 2 || sectionHost == null) return;
        if (spectrumPanel != null && spectrumPanel.getParent() instanceof ViewGroup)
            ((ViewGroup) spectrumPanel.getParent()).removeView(spectrumPanel);
        sectionHost.removeAllViews();
        LinearLayout screen = createPaperPage(NIGHT);
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(false); scroller.setVerticalScrollBarEnabled(false);
        screen.addView(scroller, new LinearLayout.LayoutParams(-1, -1));
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        scroller.addView(body);
        TextView kicker = text("GLIPS / SOUND ROOM   /   03", 10, CORAL, true);
        kicker.setLetterSpacing(.16f); body.addView(kicker);
        TextView first = editorial("see the", 44, WHITE, true);
        LinearLayout.LayoutParams firstLp = new LinearLayout.LayoutParams(-1, -2);
        firstLp.topMargin = dp(14); body.addView(first, firstLp);
        TextView second = editorial("sound.", 45, CORAL, false);
        second.setTypeface(fontFor(Typeface.ITALIC));
        body.addView(second);
        TextView intro = text("Four visual frequency ranges from the playing video · no instrument separation", 12, MUTED, false);
        intro.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(14); body.addView(intro, ip);
        TextView now = text(current == null ? "NO VIDEO SELECTED" : "NOW PLAYING   /   " + current.clip.title,
                10, CORAL, true);
        now.setSingleLine(true); now.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(22); np.bottomMargin = dp(12); body.addView(now, np);
        if (current == null) {
            TextView action = actionChip("CHOOSE VIDEOS IN SHELF ↗", true, false);
            body.addView(action, new LinearLayout.LayoutParams(-1, dp(56)));
            action.setOnClickListener(v -> selectTab(1));
        } else {
            if (soundEnabled && hasPermission(Manifest.permission.RECORD_AUDIO)) {
                spectrumPanel.setVisibility(View.VISIBLE);
                body.addView(spectrumPanel, new LinearLayout.LayoutParams(-1, dp(252)));
            } else {
                TextView standby = text("◌  THE ROOM IS QUIET\n\nTurn on waves to see the sound frequencies move.", 14, MUTED, false);
                standby.setGravity(Gravity.CENTER);
                standby.setBackground(pill(0xFF282625, 0xFF5C5552, 17, 1));
                body.addView(standby, new LinearLayout.LayoutParams(-1, dp(252)));
            }
            TextView switcher = actionChip(soundEnabled ? "TURN WAVES OFF  ×" : "START THE WAVES  ↗", !soundEnabled, false);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(49));
            sp.topMargin = dp(13); body.addView(switcher, sp);
            switcher.setOnClickListener(v -> toggleSoundVisuals());
            TextView hint = text("Tap: change pattern  ·  Hold: focus a frequency", 11, MUTED, false);
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
            hp.topMargin = dp(13); body.addView(hint, hp);
        }
        TextView privacy = text("LOCAL AUDIO SESSION ONLY   /   NO RECORDING   /   NO UPLOAD", 9, 0xFF828A81, true);
        privacy.setLetterSpacing(.07f);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(22); body.addView(privacy, pp);
    }

    // PROFILE STUDIO: each local account owns its own visual identity.
    private void addProfileIdentity(LinearLayout body) {
        ClipStore.Profile p = store.currentProfile();
        int color = PROFILE_PALETTE[p.paletteIndex];
        int layout = p.layoutIndex;
        FrameLayout banner = new FrameLayout(this);
        banner.setBackground(pill(color, 0, 18, 0));
        banner.setClipToOutline(true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,
                dp(layout == 2 ? 122 : layout == 1 ? 137 : 188));
        bp.topMargin = dp(19);
        body.addView(banner, bp);
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{color, mix(color, 0xFF182527, .46f), 0xFF182527});
        banner.setBackground(gradient);
        Bitmap cover = ProfilePhotoStore.loadCover(this, p.coverFile);
        if (cover != null) {
            ImageView photo = new ImageView(this);
            photo.setImageBitmap(cover);
            photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
            banner.addView(photo, new FrameLayout.LayoutParams(-1, -1));
            View overlayShade = new View(this);
            overlayShade.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                    new int[]{0xCC101617, 0x44212626, 0x33101617}));
            banner.addView(overlayShade, new FrameLayout.LayoutParams(-1, -1));
        }
        TextView edition = text("GALLERYFLOW  /  PRIVATE EDITION", 9, WHITE, true);
        edition.setLetterSpacing(.14f);
        FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        ep.setMargins(dp(18), dp(15), dp(15), 0);
        banner.addView(edition, ep);
        TextView stamp = text(p.status.isEmpty() ? "✦  MY FILM DIARY" : p.status, 10, WHITE, true);
        stamp.setMaxLines(2);
        stamp.setEllipsize(android.text.TextUtils.TruncateAt.END);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        sp.setMargins(dp(18), 0, dp(18), dp(13));
        banner.addView(stamp, sp);
        banner.setContentDescription(tr("Choose profile cover image"));
        banner.setOnClickListener(v -> chooseCoverImage());

        LinearLayout personal = new LinearLayout(this);
        personal.setGravity(Gravity.CENTER_VERTICAL);
        personal.setOrientation(layout == 2 ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        personal.setPadding(dp(layout == 1 ? 16 : 7), dp(13), dp(8), dp(9));
        if (layout == 1) personal.setBackground(pill(darkPaper() ? 0xFF303739 : 0xFFF4F1E8,
                darkPaper() ? 0xFF4B5657 : 0xFFCECABF, 15, 1));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-1, -2);
        pl.topMargin = dp(layout == 1 ? 10 : 3);
        body.addView(personal, pl);
        ProfileAvatarView face = new ProfileAvatarView(this, layout == 2 ? 37 : 42);
        face.showProfile(p);
        LinearLayout.LayoutParams faceLp = new LinearLayout.LayoutParams(dp(layout == 2 ? 70 : 78),
                dp(layout == 2 ? 70 : 78));
        if (layout == 2) faceLp.bottomMargin = dp(10);
        personal.addView(face, faceLp);
        face.setOnClickListener(v -> chooseProfilePhoto());
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        if (layout != 2) labels.setPadding(dp(14), 0, 0, 0);
        personal.addView(labels, new LinearLayout.LayoutParams(layout == 2 ? -1 : 0, -2,
                layout == 2 ? 0f : 1f));
        TextView displayName = editorial("", layout == 2 ? 38 : 24, INK, true);
        rawText(displayName, p.name);
        displayName.setMaxLines(2);
        displayName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labels.addView(displayName);
        int liked = 0;
        for (Clip clip : store.clips) if (store.isFavorite(clip)) liked++;
        TextView metadata = text(liked + " kept films  ·  local profile", 11,
                darkPaper() ? 0xFFB5BCB6 : 0xFF77766F, false);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
        ml.topMargin = dp(6); labels.addView(metadata, ml);
        if (!p.bio.isEmpty()) {
            TextView about = text("", 13, darkPaper() ? 0xFFE0E6E1 : 0xFF60645E, false);
            rawText(about, p.bio);
            about.setLineSpacing(dp(3), 1.0f);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
            ap.topMargin = dp(12); body.addView(about, ap);
        }
        TextView photoLink = text("CHANGE PORTRAIT  ↗", 10, RUST, true);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-1, -2);
        ll.topMargin = dp(9); body.addView(photoLink, ll);
        photoLink.setOnClickListener(v -> chooseProfilePhoto());
    }

    private int mix(int a, int b, float fraction) {
        float t = Math.max(0f, Math.min(1f, fraction));
        return Color.rgb(Math.round(Color.red(a) * (1f - t) + Color.red(b) * t),
                Math.round(Color.green(a) * (1f - t) + Color.green(b) * t),
                Math.round(Color.blue(a) * (1f - t) + Color.blue(b) * t));
    }

    private void chooseProfileColour() {
        ClipStore.Profile p = store.currentProfile();
        String[] choices = new String[PROFILE_COLORS.length];
        for (int i = 0; i < choices.length; i++) choices[i] = tr(PROFILE_COLORS[i]);
        new AlertDialog.Builder(this).setTitle(tr("PROFILE COLOUR"))
                .setSingleChoiceItems(choices, p.paletteIndex, (d, which) -> {
                    d.dismiss(); store.setCurrentPalette(which);
                    if (headerAvatar != null) headerAvatar.showProfile(store.currentProfile());
                    renderProfileScreen();
                }).setNegativeButton(tr("Cancel"), null).show();
    }

    private void chooseProfileLayout() {
        ClipStore.Profile p = store.currentProfile();
        String[] choices = new String[PROFILE_LAYOUTS.length];
        for (int i = 0; i < choices.length; i++) choices[i] = tr(PROFILE_LAYOUTS[i]);
        new AlertDialog.Builder(this).setTitle(tr("PROFILE LAYOUT"))
                .setSingleChoiceItems(choices, p.layoutIndex, (d, which) -> {
                    d.dismiss(); store.setCurrentLayout(which); renderProfileScreen();
                }).setNegativeButton(tr("Cancel"), null).show();
    }

    private void editProfileWriting(boolean biography) {
        ClipStore.Profile p = store.currentProfile();
        EditText input = new EditText(this);
        input.setText(biography ? p.bio : p.status);
        input.setHint(tr(biography ? "A few words about you" : "Your current mood"));
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(biography ? 160 : 48)});
        input.setSingleLine(!biography);
        if (biography) { input.setMinLines(3); input.setMaxLines(5); }
        input.setTextColor(0xFF1B2020);
        input.setHintTextColor(0xFF62686B);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(22), dp(12), dp(22), dp(4));
        box.addView(input, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle(tr(biography ? "ABOUT ME" : "SHORT STATUS"))
                .setView(box).setNegativeButton(tr("Cancel"), null)
                .setPositiveButton(tr("Save"), (dialog, which) -> {
                    if (biography) store.setCurrentBio(input.getText().toString());
                    else store.setCurrentStatus(input.getText().toString());
                    renderProfileScreen();
                }).show();
    }

    private void renderProfileScreen() {
        if (selectedTab != 3 || sectionHost == null) return;
        sectionHost.removeAllViews();
        LinearLayout screen = createPaperPage(PAPER);
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        screen.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(body);
        addSectionHeading(body, "PERSONAL ARCHIVE     /     04", "your corner.",
                "No online account · No followers · No sign-in", false);
        addProfileIdentity(body);
        int liked = 0;
        for (Clip film : store.clips) if (store.isFavorite(film)) liked++;

        LinearLayout controls = new LinearLayout(this);
        LinearLayout.LayoutParams ctl = new LinearLayout.LayoutParams(-1, dp(45));
        ctl.topMargin = dp(10); body.addView(controls, ctl);
        TextView change = actionChip("◉  CHANGE PHOTO", true, true);
        controls.addView(change, new LinearLayout.LayoutParams(0, -1, 1));
        change.setOnClickListener(v -> chooseProfilePhoto());
        TextView rename = actionChip("RENAME ↗", false, true);
        LinearLayout.LayoutParams relp = new LinearLayout.LayoutParams(0, -1, 1);
        relp.leftMargin = dp(8); controls.addView(rename, relp);
        rename.setOnClickListener(v -> promptProfileName(true));

        TextView customize = text("MAKE IT YOURS  /  PROFILE STUDIO", 10, RUST, true);
        customize.setLetterSpacing(.11f);
        LinearLayout.LayoutParams customizeLp = new LinearLayout.LayoutParams(-1, dp(36));
        customizeLp.topMargin = dp(17); body.addView(customize, customizeLp);
        addSettingRow(body, "COVER IMAGE", "CHOOSE ↗", this::chooseCoverImage);
        if (!store.currentProfile().coverFile.isEmpty())
            addSettingRow(body, "REMOVE COVER", "CLEAR ×", this::removeCoverImage);
        addSettingRow(body, "PROFILE COLOUR", tr(PROFILE_COLORS[store.currentProfile().paletteIndex]) + " ↗",
                this::chooseProfileColour);
        addSettingRow(body, "PROFILE LAYOUT", tr(PROFILE_LAYOUTS[store.currentProfile().layoutIndex]) + " ↗",
                this::chooseProfileLayout);
        addSettingRow(body, "SHORT STATUS", "EDIT ↗", () -> editProfileWriting(false));
        addSettingRow(body, "ABOUT ME", "EDIT ↗", () -> editProfileWriting(true));

        LinearLayout typeRow = new LinearLayout(this);
        typeRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams typeLp = new LinearLayout.LayoutParams(-1, dp(54));
        typeLp.topMargin = dp(12); body.addView(typeRow, typeLp);
        TextView typeLabel = text("TYPEFACE  /  " + fontStyle.toUpperCase(Locale.US), 11, INK, true);
        typeRow.addView(typeLabel, new LinearLayout.LayoutParams(0, -2, 1));
        TextView typeAction = actionChip("CHANGE FONT ↗", false, true);
        typeRow.addView(typeAction, new LinearLayout.LayoutParams(dp(157), dp(42)));
        typeAction.setOnClickListener(v -> chooseFontStyle());

        addSettingRow(body, "APP LANGUAGE", languageLabel() + " ↗", this::chooseLanguage);
        addSettingRow(body, "APPEARANCE", tr(THEMES[themeMode]) + " ↗", this::chooseThemeMode);
        addSettingRow(body, "ACCENT COLOUR", tr(ACCENT_NAMES[accentIndex]) + " ↗", this::chooseAccent);
        addSettingRow(body, "AMBIENT LIGHT", ambientEnabled ? "ON  ◉" : "OFF  ○",
                () -> setAmbientEnabled(!ambientEnabled));
        addSettingRow(body, "AMBIENT STRENGTH", tr(AMBIENT_STRENGTHS[ambientStrengthIndex]) + " ↗",
                this::chooseAmbientStrength);
        addSettingRow(body, "FOCUS MODE", focusMode ? "ON  ◉" : "OFF  ○",
                () -> setFocusMode(!focusMode));

        TextView buildTag = text("GlipsFlow  /  0.1.1alpha  ·  ON-DEVICE EDITION", 10, 0xFF77766F, true);
        buildTag.setLetterSpacing(.09f);
        LinearLayout.LayoutParams buildTagLp = new LinearLayout.LayoutParams(-1, dp(32));
        buildTagLp.topMargin = dp(12);
        body.addView(buildTag, buildTagLp);

        addStorageSummary(body);

        TextView label = text("YOUR LOCAL PROFILES", 10, 0xFF686C62, true);
        label.setLetterSpacing(.14f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(24); lp.bottomMargin = dp(10); body.addView(label, lp);
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        body.addView(hsv, new LinearLayout.LayoutParams(-1, dp(77)));
        LinearLayout profilesRow = new LinearLayout(this);
        hsv.addView(profilesRow);
        for (ClipStore.Profile profile : store.profiles) {
            boolean active = profile == store.currentProfile();
            LinearLayout pill = new LinearLayout(this);
            pill.setPadding(dp(8), dp(7), dp(12), dp(7));
            pill.setGravity(Gravity.CENTER_VERTICAL);
            pill.setBackground(pill(active ? (darkPaper() ? 0xFF403431 : 0xFFF1CEC7) : 0xFFF6F3EA,
                    active ? (darkPaper() ? 0xFFAE857D : 0xFFAA6558) : 0xFFC9C9BE, 14, 1));
            LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(-2, dp(60));
            pLp.rightMargin = dp(9); profilesRow.addView(pill, pLp);
            ProfileAvatarView face = new ProfileAvatarView(this, 28);
            face.showProfile(profile);
            pill.addView(face, new LinearLayout.LayoutParams(dp(43), dp(43)));
            TextView tag = text("", 12, INK, true); rawText(tag, profile.name);
            tag.setSingleLine(true);
            tag.setPadding(dp(8), 0, 0, 0);
            pill.addView(tag);
            pill.setOnClickListener(v -> {
                store.switchProfile(profile.id);
                if (headerAvatar != null) headerAvatar.showProfile(store.currentProfile());
                if (!store.clips.isEmpty()) showClip(Math.min(store.savedIndex(), store.clips.size() - 1));
                renderProfileScreen();
            });
        }
        TextView create = actionChip("+  ADD LOCAL PROFILE", false, true);
        LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(-1, dp(45));
        aLp.topMargin = dp(5); body.addView(create, aLp);
        create.setOnClickListener(v -> promptProfileName(false));

        LinearLayout keeper = new LinearLayout(this);
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(-1, dp(52));
        klp.topMargin = dp(24); body.addView(keeper, klp);
        TextView keeperName = text("THE KEEPERS  ·  ♥", 12, INK, true);
        keeperName.setLetterSpacing(.08f);
        keeper.addView(keeperName, new LinearLayout.LayoutParams(0, -2, 1));
        TextView keeperCount = text(String.format(Locale.US, "%02d SAVED", liked), 10, 0xFF77766F, true);
        keeper.addView(keeperCount);
        LinearLayout mini = new LinearLayout(this);
        mini.setGravity(Gravity.CENTER_VERTICAL);
        mini.setBackground(pill(0xFFE0DDCF, 0xFFBFC0B3, 12, 1));
        mini.setPadding(dp(9), dp(9), dp(9), dp(9));
        body.addView(mini, new LinearLayout.LayoutParams(-1, dp(118)));
        int shown = 0;
        for (int i = 0; i < store.clips.size() && shown < 4; i++) {
            if (!store.isFavorite(store.clips.get(i))) continue;
            Clip clip = store.clips.get(i);
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(0, -1, 1);
            ilp.rightMargin = dp(5); mini.addView(image, ilp);
            ThumbnailLoader.load(this, clip, image);
            final int position = i;
            image.setOnClickListener(v -> { selectTab(0); wantedPlaying = true; showClip(position); });
            shown++;
        }
        if (shown == 0) {
            TextView noLiked = text("No saved videos yet.\nTap ♥ while watching to keep a film here.", 13, 0xFF666B61, false);
            noLiked.setGravity(Gravity.CENTER);
            mini.addView(noLiked, new LinearLayout.LayoutParams(-1, -1));
        }
        TextView viewLiked = actionChip("VIEW ALL KEPT FILMS  ↗", true, true);
        LinearLayout.LayoutParams likedLp = new LinearLayout.LayoutParams(-1, dp(48));
        likedLp.topMargin = dp(10); body.addView(viewLiked, likedLp);
        viewLiked.setOnClickListener(v -> { shelfLikedOnly = true; selectTab(1); });
        TextView backupLabel = text("KEEP YOUR ARCHIVE SAFE", 10, 0xFF77766F, true);
        backupLabel.setLetterSpacing(.12f);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.topMargin = dp(28); body.addView(backupLabel, blp);
        TextView explain = text("Save names, portraits and likes to a file before replacing the APK or changing phones.", 11, 0xFF77766F, false);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
        elp.topMargin = dp(6); elp.bottomMargin = dp(10); body.addView(explain, elp);
        LinearLayout backupRow = new LinearLayout(this);
        body.addView(backupRow, new LinearLayout.LayoutParams(-1, dp(46)));
        TextView export = actionChip("BACK UP ↗", true, true);
        backupRow.addView(export, new LinearLayout.LayoutParams(0, -1, 1));
        export.setOnClickListener(v -> startBackupExport());
        TextView restore = actionChip("RESTORE ↗", false, true);
        LinearLayout.LayoutParams restoreLp = new LinearLayout.LayoutParams(0, -1, 1);
        restoreLp.leftMargin = dp(8); backupRow.addView(restore, restoreLp);
        restore.setOnClickListener(v -> startBackupImport());

        TextView delete = text("DELETE THIS PROFILE", 11, RUST, true);
        delete.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(-1, dp(60));
        deleteLp.topMargin = dp(13); body.addView(delete, deleteLp);
        delete.setOnClickListener(v -> {
            if (store.profiles.size() < 2) { toast("At least one profile is required"); return; }
            new AlertDialog.Builder(this)
                .setTitle(tr("Delete this local profile?"))
                .setMessage(tr("Only this profile, its portrait, and saved likes will be deleted. Your gallery videos are not deleted."))
                .setNegativeButton(tr("Cancel"), null)
                .setPositiveButton(tr("Delete"), (d, which) -> {
                    String picture = store.currentProfile().avatarFile;
                    String bannerFile = store.currentProfile().coverFile;
                    if (store.removeCurrentProfile()) {
                        ProfilePhotoStore.delete(this, picture);
                        ProfilePhotoStore.delete(this, bannerFile);
                        if (!store.clips.isEmpty()) showClip(Math.min(store.savedIndex(), store.clips.size() - 1));
                        renderProfileScreen();
                    }
                }).show();
        });
    }

    private void showLibrary() {
        if (isAnimating) return;
        if (store.clips.isEmpty()) { if (hasVideoAccess()) refreshGallery(); else requestVideoAccess(); return; }
        Dialog dialog = new Dialog(this);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(20), dp(18), dp(20), dp(15));
        sheet.setBackground(pill(0xFF181A1F, 0xFF34363C, 25, 1));
        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        sheet.addView(heading);
        TextView headingName = text("the contact sheet.", 26, WHITE, true);
        heading.addView(headingName, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = text("×", 30, WHITE, false);
        close.setPadding(dp(12), 0, dp(6), 0);
        heading.addView(close);
        close.setOnClickListener(v -> dialog.dismiss());
        TextView count = text(store.clips.size() + " local films  /  newest first  /  " + store.currentProfile().name, 12, MUTED, false);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(7); sheet.addView(count, cp);

        LinearLayout tabs = new LinearLayout(this);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(46));
        tp.topMargin = dp(18); sheet.addView(tabs, tp);
        TextView all = text("ALL FILMS", 12, NIGHT, true);
        TextView saved = text("♥  MY SAVES", 12, WHITE, true);
        for (TextView t : new TextView[]{all, saved}) {
            t.setGravity(Gravity.CENTER);
            tabs.addView(t, new LinearLayout.LayoutParams(0, -1, 1));
        }
        ScrollView scroll = new ScrollView(this);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, 0, 1);
        slp.topMargin = dp(10); sheet.addView(scroll, slp);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        final boolean[] likedOnly = {false};
        Runnable[] render = new Runnable[1];
        render[0] = () -> {
            all.setTextColor(likedOnly[0] ? WHITE : NIGHT);
            saved.setTextColor(likedOnly[0] ? NIGHT : WHITE);
            all.setBackground(pill(likedOnly[0] ? 0xFF2B2D33 : CORAL, 0, 12, 0));
            saved.setBackground(pill(likedOnly[0] ? CORAL : 0xFF2B2D33, 0, 12, 0));
            list.removeAllViews();
            int shown = 0;
            for (int i = 0; i < store.clips.size(); i++) {
                Clip clip = store.clips.get(i);
                if (likedOnly[0] && !store.isFavorite(clip)) continue;
                int position = i;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(8), dp(7), dp(8), dp(7));
                if (i == currentIndex) row.setBackground(pill(0xFF323630, 0, 10, 0));
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, dp(83));
                rowLp.bottomMargin = dp(4); list.addView(row, rowLp);

                ImageView thumb = new ImageView(this);
                thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                thumb.setBackground(pill(CARD, 0, 9, 0));
                row.addView(thumb, new LinearLayout.LayoutParams(dp(56), dp(68)));
                ThumbnailLoader.load(this, clip, thumb);
                LinearLayout meta = new LinearLayout(this);
                meta.setOrientation(LinearLayout.VERTICAL);
                meta.setPadding(dp(12), 0, dp(4), 0);
                row.addView(meta, new LinearLayout.LayoutParams(0, -2, 1));
                TextView label = text("", 14, WHITE, true); rawText(label, clip.title);
                label.setMaxLines(1);
                label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                meta.addView(label);
                TextView secondary = text(readableDate(clip.addedAtMillis)
                        + (store.isFavorite(clip) ? "  ·  LIKED ♥" : "  ·  LOCAL"), 10, MUTED, false);
                LinearLayout.LayoutParams sec = new LinearLayout.LayoutParams(-1, -2);
                sec.topMargin = dp(6); meta.addView(secondary, sec);
                TextView heart = text(store.isFavorite(clip) ? "♥" : "♡", 25,
                        store.isFavorite(clip) ? CORAL : WHITE, false);
                heart.setGravity(Gravity.CENTER);
                row.addView(heart, new LinearLayout.LayoutParams(dp(40), dp(48)));
                heart.setContentDescription("Like or unlike this video for the current profile");
                heart.setOnClickListener(v -> { store.toggleFavorite(clip); render[0].run(); updateControls(); });
                row.setOnClickListener(v -> {
                    dialog.dismiss(); resetHistoryTo(position); wantedPlaying = true; showClip(position);
                });
                shown++;
                if (shown >= 150) break; // Avoid creating thousands of rows on the UI thread.
            }
            if (shown == 0) {
                TextView none = text("No liked videos yet.\nTap ♥ on a video to save it for this profile.", 14, MUTED, false);
                none.setGravity(Gravity.CENTER);
                none.setPadding(dp(14), dp(50), dp(14), dp(50));
                list.addView(none);
            } else if (shown == 150) {
                TextView note = text("Showing first 150 videos here. Keep swiping to watch the rest.", 11, MUTED, false);
                note.setPadding(dp(12), dp(20), dp(12), dp(20));
                list.addView(note);
            }
        };
        all.setOnClickListener(v -> { likedOnly[0] = false; render[0].run(); });
        saved.setOnClickListener(v -> { likedOnly[0] = true; render[0].run(); });
        render[0].run();
        LinearLayout actions = new LinearLayout(this);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(12); sheet.addView(actions, bp);
        TextView people = text("◉  YOUR CORNER", 12, NIGHT, true);
        people.setGravity(Gravity.CENTER);
        people.setBackground(pill(CORAL, 0, 14, 0));
        actions.addView(people, new LinearLayout.LayoutParams(0, dp(50), 1));
        people.setOnClickListener(v -> { dialog.dismiss(); showProfiles(); });
        TextView refresh = text("↻ REFRESH", 12, WHITE, true);
        refresh.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(114), dp(50));
        rp.leftMargin = dp(10); actions.addView(refresh, rp);
        refresh.setBackground(pill(0xFF32363F, 0, 14, 0));
        refresh.setOnClickListener(v -> { dialog.dismiss(); refreshGallery(); });
        showBottomDialog(dialog, sheet, .74f);
    }

    private void startBackupExport() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "GlipsFlow_local_backup.json");
        try { startActivityForResult(i, EXPORT_ARCHIVE); }
        catch (Exception ex) { toast("Cannot open file saver on this phone"); }
    }

    private void startBackupImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        try { startActivityForResult(i, IMPORT_ARCHIVE); }
        catch (Exception ex) { toast("Cannot open file picker on this phone"); }
    }

    private void handleArchiveResult(int requestCode, Uri uri) {
        if (requestCode == EXPORT_ARCHIVE) {
            scanWorker.execute(() -> {
                boolean ok = false;
                try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new IllegalArgumentException("Cannot write to file");
                    LocalArchiveBackup.exportTo(getApplicationContext(), store, out);
                    ok = true;
                } catch (Exception ignored) { }
                boolean success = ok;
                handler.post(() -> { if (!alreadyDestroyed) toast(success ?
                    "Backup saved. Keep this file safe." : "Could not save backup"); });
            });
        } else if (requestCode == IMPORT_ARCHIVE) {
            new AlertDialog.Builder(this)
                .setTitle(tr("Restore local profiles?"))
                .setMessage(tr("This will replace profiles, their pictures and likes inside GlipsFlow. Original videos will not be changed."))
                .setNegativeButton(tr("Cancel"), null)
                .setPositiveButton(tr("Restore"), (d, which) -> {
                    scanWorker.execute(() -> {
                        boolean ok = false;
                        try (InputStream in = getContentResolver().openInputStream(uri)) {
                            if (in == null) throw new IllegalArgumentException("File unavailable");
                            LocalArchiveBackup.importFrom(getApplicationContext(), store, in);
                            ok = true;
                        } catch (Exception ignored) { }
                        boolean success = ok;
                        handler.post(() -> {
                            if (alreadyDestroyed) return;
                            if (success) {
                                if (store.clips.isEmpty()) showEmpty();
                                else showClip(Math.min(store.savedIndex(), store.clips.size() - 1));
                                renderProfileScreen();
                                toast("Profiles and likes restored");
                            } else toast("Invalid or unreadable GlipsFlow backup");
                        });
                    });
                }).show();
        }
    }

    private void chooseCoverImage() {
        coverProfileId = store.currentProfile().id;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try { startActivityForResult(intent, PICK_COVER); }
        catch (Exception error) { toast("No image picker available"); }
    }

    private void removeCoverImage() {
        String old = store.currentProfile().coverFile;
        store.clearCurrentCover();
        ProfilePhotoStore.delete(this, old);
        renderProfileScreen();
    }

    private void chooseProfilePhoto() {
        photoProfileId = store.currentProfile().id;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try { startActivityForResult(intent, PICK_PHOTO); }
        catch (Exception ex) { toast("No photo picker available on this device"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (requestCode == EXPORT_ARCHIVE || requestCode == IMPORT_ARCHIVE) {
            handleArchiveResult(requestCode, data.getData());
            return;
        }
        if (requestCode == PICK_FONT) {
            importFont(data.getData());
            return;
        }
        if (requestCode == PICK_COVER) {
            final Uri picked = data.getData();
            final String profileId = coverProfileId;
            scanWorker.execute(() -> {
                String file = null;
                try { file = ProfilePhotoStore.saveCover(getApplicationContext(), picked); }
                catch (Exception ignored) { }
                final String finalFile = file;
                handler.post(() -> {
                    if (alreadyDestroyed || isFinishing() || isDestroyed()) {
                        ProfilePhotoStore.delete(getApplicationContext(), finalFile); return;
                    }
                    if (finalFile == null) { toast("Could not open cover photo"); return; }
                    if (profileId != null && store.currentProfile().id.equals(profileId)) {
                        String previous = store.currentProfile().coverFile;
                        if (store.setCurrentCover(finalFile)) {
                            ProfilePhotoStore.delete(this, previous);
                            renderProfileScreen();
                            toast("Cover saved on this phone");
                        }
                    } else ProfilePhotoStore.delete(this, finalFile);
                });
            });
            return;
        }
        if (requestCode != PICK_PHOTO) return;
        final Uri chosen = data.getData();
        final String profileId = photoProfileId;
        scanWorker.execute(() -> {
            String file = null;
            try { file = ProfilePhotoStore.save(getApplicationContext(), chosen); }
            catch (Exception ignored) { }
            String result = file;
            handler.post(() -> {
                if (alreadyDestroyed || isFinishing() || isDestroyed()) {
                    if (result != null) ProfilePhotoStore.delete(getApplicationContext(), result);
                    return;
                }
                if (result == null) { toast("Could not read that picture. Try a different one."); return; }
                if (profileId != null && store.currentProfile().id.equals(profileId)) {
                    String previous = store.currentProfile().avatarFile;
                    if (store.setCurrentAvatar(result)) {
                        ProfilePhotoStore.delete(this, previous);
                        if (headerAvatar != null) headerAvatar.showProfile(store.currentProfile());
                        toast("Profile picture saved on this phone");
                        if (selectedTab == 3) renderProfileScreen();
                    }
                } else {
                    ProfilePhotoStore.delete(this, result);
                    toast("Profile changed. Choose photo again.");
                }
            });
        });
    }

    private void showProfiles() {
        if (isAnimating) return;
        Dialog dialog = new Dialog(this);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(21), dp(19), dp(21), dp(17));
        sheet.setBackground(pill(0xFFF3F0E8, 0, 24, 0));
        final int ink = INK, dim = 0xFF646867, accent = shadeForWhite();

        TextView kicker = text("PERSONAL ARCHIVE   /   NO. 01", 10, accent, true);
        kicker.setLetterSpacing(.12f);
        sheet.addView(kicker);
        TextView title = text("Your little corner.", 27, ink, true);
        title.setLetterSpacing(-.05f);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(4);
        sheet.addView(title, titleLp);

        LinearLayout hero = new LinearLayout(this);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(13), dp(10), dp(12), dp(10));
        hero.setBackground(pill(0xFFE5E1D7, 0, 17, 0));
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, dp(102));
        heroLp.topMargin = dp(14); sheet.addView(hero, heroLp);
        ProfileAvatarView heroPhoto = new ProfileAvatarView(this, 44);
        heroPhoto.showProfile(store.currentProfile());
        hero.addView(heroPhoto, new LinearLayout.LayoutParams(dp(79), dp(79)));
        heroPhoto.setOnClickListener(v -> { dialog.dismiss(); chooseProfilePhoto(); });
        LinearLayout desc = new LinearLayout(this);
        desc.setOrientation(LinearLayout.VERTICAL);
        desc.setPadding(dp(13), 0, 0, 0);
        hero.addView(desc, new LinearLayout.LayoutParams(0, -2, 1));
        TextView profileName = text("", 17, ink, true); rawText(profileName, store.currentProfile().name);
        profileName.setMaxLines(1);
        profileName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        desc.addView(profileName);
        TextView tagline = text("ONLY ON THIS PHONE", 9, dim, true);
        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(-1, -2);
        tagLp.topMargin = dp(4); desc.addView(tagline, tagLp);
        TextView photoButton = text("EDIT PHOTO  ↗", 11, accent, true);
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(-1, -2);
        pbLp.topMargin = dp(8); desc.addView(photoButton, pbLp);
        photoButton.setOnClickListener(v -> { dialog.dismiss(); chooseProfilePhoto(); });

        TextView section = text("SWITCH PROFILES", 10, dim, true);
        section.setLetterSpacing(.12f);
        LinearLayout.LayoutParams secLp = new LinearLayout.LayoutParams(-1, -2);
        secLp.topMargin = dp(17); secLp.bottomMargin = dp(9);
        sheet.addView(section, secLp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sheet.addView(scroll, sp);
        LinearLayout items = new LinearLayout(this);
        items.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(items);
        for (ClipStore.Profile profile : store.profiles) {
            boolean selected = profile == store.currentProfile();
            LinearLayout row = new LinearLayout(this);
            row.setPadding(dp(10), dp(9), dp(12), dp(9));
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(pill(selected ? 0xFFDDD9CB : 0xFFFAF8F3, selected ? accent : 0xFFE3E0D9, 13, 1));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, dp(66));
            rowLp.bottomMargin = dp(7); items.addView(row, rowLp);
            ProfileAvatarView face = new ProfileAvatarView(this, 28);
            face.showProfile(profile);
            row.addView(face, new LinearLayout.LayoutParams(dp(45), dp(45)));
            LinearLayout words = new LinearLayout(this);
            words.setPadding(dp(12), 0, 0, 0);
            words.setOrientation(LinearLayout.VERTICAL);
            row.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
            TextView name = text("", 15, ink, true); rawText(name, profile.name); words.addView(name);
            int likesCount = 0;
            for (Clip video : store.clips) if (profile.likes.contains(video.key())) likesCount++;
            TextView count = text(likesCount + " saved films" + (selected ? "  ·  YOU ARE HERE" : ""), 10, dim, false);
            count.setPadding(0, dp(4), 0, 0); words.addView(count);
            TextView arrow = text(selected ? "●" : "↗", 17, accent, true);
            row.addView(arrow);
            row.setOnClickListener(v -> {
                dialog.dismiss(); store.switchProfile(profile.id);
                if (headerAvatar != null) headerAvatar.showProfile(store.currentProfile());
                resetHistoryTo(0);
                if (store.clips.isEmpty()) showEmpty();
                else showClip(Math.min(store.savedIndex(), store.clips.size() - 1));
                toast("Now viewing as " + profile.name);
            });
        }
        TextView add = text("＋  NEW LOCAL PROFILE", 12, 0xFFFFFFFF, true);
        add.setGravity(Gravity.CENTER);
        add.setBackground(pill(ink, 0, 12, 0));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, dp(48));
        alp.topMargin = dp(8); sheet.addView(add, alp);
        add.setOnClickListener(v -> { dialog.dismiss(); promptProfileName(false); });
        LinearLayout actions = new LinearLayout(this);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(43));
        op.topMargin = dp(6); sheet.addView(actions, op);
        TextView rename = text("RENAME", 11, ink, true); rename.setGravity(Gravity.CENTER);
        actions.addView(rename, new LinearLayout.LayoutParams(0, -1, 1));
        rename.setOnClickListener(v -> { dialog.dismiss(); promptProfileName(true); });
        TextView remove = text("DELETE PROFILE", 11, accent, true); remove.setGravity(Gravity.CENTER);
        actions.addView(remove, new LinearLayout.LayoutParams(0, -1, 1));
        remove.setOnClickListener(v -> {
            dialog.dismiss();
            if (store.profiles.size() == 1) { toast("Keep at least one local profile"); return; }
            new AlertDialog.Builder(this).setTitle(tr("Delete this profile?"))
                    .setMessage("This removes the local profile, its picture, and saved likes. Videos in the gallery are not deleted.")
                    .setNegativeButton(tr("Cancel"), null)
                    .setPositiveButton(tr("Delete"), (d, which) -> {
                        String avatarToDelete = store.currentProfile().avatarFile;
                        store.removeCurrentProfile();
                        ProfilePhotoStore.delete(this, avatarToDelete);
                        if (store.clips.isEmpty()) showEmpty();
                        else showClip(Math.min(store.savedIndex(), store.clips.size() - 1));
                        showProfiles();
                    }).show();
        });
        showBottomDialog(dialog, sheet, .79f);
    }

    private void promptProfileName(boolean rename) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Color.BLACK);
        input.setHint("Profile name");
        input.setText(rename ? store.currentProfile().name : "");
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(dp(20), dp(8), dp(20), 0);
        wrapper.addView(input, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
                .setTitle(tr(rename ? "Rename profile" : "Create local profile"))
                .setView(wrapper)
                .setNegativeButton(tr("Cancel"), null)
                .setPositiveButton(tr(rename ? "Save" : "Create"), (dialog, which) -> {
                    if (rename) {
                        if (!store.renameCurrent(input.getText().toString())) toast("Enter a profile name");
                        else { if (!store.clips.isEmpty()) updateHud(); if (selectedTab == 3) renderProfileScreen(); }
                    } else {
                        ClipStore.Profile added = store.createProfile(input.getText().toString());
                        if (added == null) toast("Enter a name (maximum 12 profiles)");
                        else {
                            if (store.clips.isEmpty()) showEmpty(); else showClip(0);
                            if (selectedTab == 3) renderProfileScreen();
                        }
                    }
                }).show();
    }

    private void showBottomDialog(Dialog dialog, View content, float heightFraction) {
        dialog.setContentView(content);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.gravity = Gravity.BOTTOM;
            attrs.dimAmount = .74f;
            window.setAttributes(attrs);
        }
        dialog.show();
        if (window != null) window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                (int) (getResources().getDisplayMetrics().heightPixels * heightFraction));
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        stage.post(() -> {
            if (stagedNext != null) stagedNext.setTranslationY(stage.getHeight());
            if (incoming != null) incoming.setTranslationY(direction == 1 ? stage.getHeight() : -stage.getHeight());
        });
        immersive();
    }
    @Override protected void onPause() {
        super.onPause();
        screenActive = false;
        handler.removeCallbacks(tick);
        if (soundController != null) soundController.detach();
        if (current != null) current.setActive(false);
    }
    @Override protected void onResume() {
        super.onResume(); immersive();
        screenActive = true;
        handler.removeCallbacks(tick);
        handler.post(tick);
        if (current != null && wantedPlaying && (selectedTab == 0 || selectedTab == 2)) current.setActive(true);
        updateSpectrumSource();
        // Re-query when returning from background, including after permissions change.
        if (store != null && hasVideoAccess()) refreshGallery();
        else if (store != null && current != null && !hasVideoAccess()) showEmpty();
    }
    @Override public void onBackPressed() {
        if (selectedTab != 0) selectTab(0);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        alreadyDestroyed = true;
        try { getContentResolver().unregisterContentObserver(galleryObserver); }
        catch (Exception ignored) { }
        handler.removeCallbacks(mediaChanged);
        handler.removeCallbacksAndMessages(null);
        scanWorker.shutdownNow();
        if (soundController != null) soundController.detach();
        disposeAllPages();
        super.onDestroy();
    }
}
