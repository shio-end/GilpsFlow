package com.galleryflow.app;

import android.media.audiofx.Visualizer;

/** Binds an Android audio-session FFT to the currently active video only. */
final class SoundSpectrumController {
    private volatile Visualizer visualizer;
    private int currentSession = -1;
    private final SoundSpectrumView view;
    private volatile boolean attached;

    SoundSpectrumController(SoundSpectrumView view) { this.view = view; }

    boolean attach(int audioSessionId) {
        if (audioSessionId <= 0) { detach(); return false; }
        if (attached && currentSession == audioSessionId) return true;
        detach();
        try {
            final Visualizer v = new Visualizer(audioSessionId);
            visualizer = v;
            int[] range = Visualizer.getCaptureSizeRange();
            int size = Math.max(range[0], Math.min(1024, range[1]));
            v.setCaptureSize(size);
            int rate = Math.max(1000, Math.min(20000, Visualizer.getMaxCaptureRate()));
            v.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override public void onWaveFormDataCapture(Visualizer fx, byte[] data, int samplingRate) { }
                @Override public void onFftDataCapture(Visualizer fx, byte[] fft, int samplingRate) {
                    if (attached && fx == visualizer) view.acceptFft(fft, samplingRate);
                }
            }, rate, false, true);
            currentSession = audioSessionId;
            attached = true;
            view.setActive(true);
            v.setEnabled(true);
            return true;
        } catch (RuntimeException error) {
            detach();
            return false;
        }
    }

    void detach() {
        attached = false;
        currentSession = -1;
        Visualizer v = visualizer;
        visualizer = null;
        if (v != null) {
            try { v.setEnabled(false); } catch (RuntimeException ignored) { }
            try { v.release(); } catch (RuntimeException ignored) { }
        }
        view.setActive(false);
    }
}
