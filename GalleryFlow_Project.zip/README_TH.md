# GlipsFlow 0.1.1alpha — Android alpha build

GlipsFlow คือแอปดูคลิปจากแกลเลอรีในโทรศัพท์แบบปัดขึ้นลง สร้างจากโค้ด GalleryFlow 9.0 ที่ผู้ใช้เคยสร้าง APK สำเร็จผ่าน GitHub Actions แล้ว

## ใหม่ในรุ่นนี้
- เปลี่ยนชื่อแอปที่แสดงบนโทรศัพท์และในหน้าฟีดเป็น **GlipsFlow**
- ไอคอน **g** แบบเรียบง่ายที่สืบทอดรูปทรงเดิม พร้อมสี **Charcoal #1F1F1F / Cream #F9F4EB / Coral #E67F6E**
- สี Accent เลือกได้: Coral (เริ่มต้น), Powder Blue, Peach, Sage
- หน้า YOU แสดงหมายเลขรุ่น **0.1.1alpha**
- ส่งออกแบ็กอัปเป็น `glipsflow.local.v1` และยังนำเข้าแบ็กอัป `galleryflow.local.v1` รุ่นเก่าได้
- คงฟังก์ชันวิดีโอจากเครื่อง เรียงคลิปใหม่ก่อน ปัดดูวิดีโอ โปรไฟล์ Local หลายโปรไฟล์ รูปโปรไฟล์/รูปปก รายการถูกใจ Sound Room, Ambient Light, โหมดโฟกัส และตัวเลือกภาษาเดิม

## เรื่องสำคัญก่อนอัปเดต

**ยังคง `applicationId = com.galleryflow.app` โดยตั้งใจ** เพื่อให้ Android มองว่า GlipsFlow เป็นแอปรุ่นใหม่ของ GalleryFlow และยังอ่านข้อมูลโปรไฟล์เดิมได้ภายใต้แอปเดียวกัน ส่วนชื่อที่เห็นบนจอคือ GlipsFlow.

- ใช้เวอร์ชันโค้ด `10` (สูงกว่า GalleryFlow 9.0 ที่ใช้ `9`) และชื่อเวอร์ชัน `0.1.1alpha`.
- **ถ้าลายเซ็น APK ไม่ตรงกับรุ่นเก่า** Android จะปฏิเสธการติดตั้งทับ นี่เป็นข้อจำกัดของ APK ที่ลงนามด้วย debug key ต่างกันข้ามการรัน GitHub Actions
- ก่อนอัปเดต ให้เปิดแอปเก่า > YOU > BACK UP เพื่อบันทึกข้อมูลสำคัญ **อย่าเพิ่งถอนแอปเก่า** จนกว่าจะมั่นใจว่ากู้คืนข้อมูลได้
- การลบโปรไฟล์ในแอปจะไม่ลบวิดีโอจากแกลเลอรี แต่ถอนการติดตั้งจะลบฐานข้อมูล Local ภายในแอปได้

## สร้าง APK ด้วยโทรศัพท์ Android (Repository เดิม)

1. ดาวน์โหลดไฟล์ `GalleryFlow_Project.zip` ที่แนบในแชต (ชื่อเก่าเพื่อให้ Workflow ที่เคยตั้งไว้ยังใช้ได้)
2. เปิด https://github.com/shio-end/GalleryFlow/upload/main
3. อัปโหลด ZIP ใหม่ **ทับไฟล์ชื่อ `GalleryFlow_Project.zip` เดิมที่ root** แล้ว Commit changes. อย่าเปลี่ยนชื่อเป็น `(1)`
4. ไป https://github.com/shio-end/GalleryFlow/actions เปิดการทำงานล่าสุด
5. หากขึ้น Success ให้เปิด Artifacts แล้วดาวน์โหลดไฟล์ ZIP ที่เก็บ APK (Workflow เดิมอาจยังตั้งชื่อ artifact ว่า `GalleryFlow-APK`)
6. แตก ZIP แล้วจะได้ `app-debug.apk` ทดลองติดตั้งบนเครื่อง Android

หากจะสร้าง Repository ใหม่แทน ให้นำ *เนื้อหาใน ZIP* ออกไปเก็บที่ root ของ Repo และใช้ `.github/workflows/build-apk.yml` ที่ให้มาด้วย แทนการอัปโหลด ZIP อย่างเดียว

## สี / โลโก้

- `app/src/main/res/mipmap-*/ic_launcher.png`: ไอคอนที่ใช้จริงทั้ง 5 ความละเอียด
- `app/src/main/java/com/galleryflow/app/MainActivity.java`: สีแบรนด์และข้อความ GlipsFlow
- `app/src/main/java/com/galleryflow/app/LanguagePack.java`: ข้อความ 4 ภาษา (อังกฤษเริ่มต้น จีน ญี่ปุ่น ไทย)

## ข้อจำกัดและสถานะ

- เวอร์ชันนี้เป็น **alpha** ไม่ใช่ APK ที่ผ่านการทดสอบกับผู้ใช้อย่างเต็มรูปแบบ
- ตรวจโครงสร้าง ZIP, XML, Java และค่าการตั้งค่าที่เปลี่ยนแล้ว แต่ในสภาพแวดล้อมนี้ไม่มี Android SDK จึงยังไม่ได้คอมไพล์ APK จริง ให้ GitHub Actions ทำขั้นตอนนั้น
- แอปยังไม่มี AI หรือระบบแยกเสียงเพลงจริง ระบบ Sound Room เป็นการแสดงความถี่เพื่อความสนุกเท่านั้น
- ไม่มีการอัปโหลดวิดีโอผ่านระบบของแอป และไม่ต้องล็อกอิน
